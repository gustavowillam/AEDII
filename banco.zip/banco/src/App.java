import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) throws Exception {
        Conta c = new Conta();
        int op = -1;

        while (op != 0) {
            op = Integer.parseInt(JOptionPane.showInputDialog(null,
                    "1 - Abrir conta \n" +
                            "2 - Efetuar depósito \n" +
                            "3 - Efetuar saque \n" +
                            "4 - Verifique seu saldo \n" +
                            "0 - Sair do programa"));
            if (op == 1) {
                c.setCliente(JOptionPane.showInputDialog(null, "Informe o nome do cliente"));
                c.setLimite(Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o limite da conta")));

            }
            if (op == 2) {

                c.deposito(Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o valor do depósito")));
            }
            if (op == 3) {

                c.saque(Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o valor do saque")));
            }
            if (op == 4) {
                JOptionPane.showMessageDialog(null, "Cliente: " + c.getCliente());
                JOptionPane.showMessageDialog(null, "Saldo: " + c.getSaldo());
                JOptionPane.showMessageDialog(null, "Limite: " + c.getLimite());
            }

        }

    }
}
