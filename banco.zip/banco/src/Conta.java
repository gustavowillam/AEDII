import javax.swing.JOptionPane;

public class Conta {
    private String cliente;
    private double saldo = 0;
    private double limite;

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public double getSaldo() {
        return saldo;
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }

    public void deposito(double valor) {
        saldo = saldo + valor;
    }

    public void saque(double valor) {
        if ((saldo + limite) >= valor)
            saldo = saldo - valor;
        else
            JOptionPane.showMessageDialog(null,
                    "Saldo insuficiente");
    }
}
