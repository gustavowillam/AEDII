import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) throws Exception {

        List<Produto> L = new ArrayList<Produto>();

        int op = -1;
        int qtd;
        while (op != 4) {
            op = Integer.parseInt(JOptionPane.showInputDialog(
                    "1-Cadastrar Produto \n" +
                            "2-Venda de Produtos \n" +
                            "3-Listagem de Produtos \n" +
                            "4-Sair do programa"));
            if (op == 1) // Cadastro de Produto
            {
                Produto p = new Produto();
                p.setNome(JOptionPane.showInputDialog("Digite o nome"));
                p.setQuantidade(Integer.parseInt(JOptionPane.showInputDialog("Digite a Quantidade")));
                p.setPreco(Double.parseDouble(JOptionPane.showInputDialog("Digite o Preço")));
                L.add(p);
            }
            if (op == 2) // Venda de Produto
            {
                String prod = JOptionPane.showInputDialog("Digite o produto p/ pesquisar");
                boolean achei = false;
                for (int i = 0; i < L.size(); i++) {
                    if (prod.equals(L.get(i).getNome())) // encontrou o produto na posição i
                    {
                        achei = true;
                        qtd = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade a ser vendida"));
                        while (qtd > L.get(i).getQuantidade()) {
                            JOptionPane.showMessageDialog(null,
                                    "Quantidade não pode ser superior ao estoque atual de " + L.get(i).getQuantidade());
                            qtd = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade a ser vendida"));
                        }
                        int qtd_atual = L.get(i).getQuantidade() - qtd;
                        L.get(i).setQuantidade(qtd_atual);
                        // L.get(i).setQuantidade(L.get(i).getQuantidade()-qtd);

                    }
                }
                if (achei == false) {
                    JOptionPane.showMessageDialog(null, "Produto não encontrado");
                }
            }
            if (op == 3) {
                String r = "";
                for (int i = 0; i < L.size(); i++) {
                    r = r + " \n Produto: " + L.get(i).getNome() +
                            " \n Estoque: " + L.get(i).getQuantidade() +
                            " \n Preço  : " + L.get(i).getPreco() + "\n";
                }
                JOptionPane.showMessageDialog(null, r);
            }

        }
    }
}
