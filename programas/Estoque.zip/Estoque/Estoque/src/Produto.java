import javax.swing.JOptionPane;

public class Produto {
    private String nome;
    private int quantidade;
    private double preco;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        if (quantidade < 0)
            JOptionPane.showMessageDialog(null, "Quantidade deve ser maior que 0");
        else
            this.quantidade = quantidade;

    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        if (preco < 0)
            JOptionPane.showMessageDialog(null, "Preço deve ser maior que 0");
        else
            this.preco = preco;
    }
}
