import javax.swing.JOptionPane;

import java.lang.Math;

public class App {
    public static void main(String[] args) {
        double x, y, p;
        x = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite a base"));
        y = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o expoente"));
        // p = potencia(x, y);
        p = Math.pow(x, y); 
        JOptionPane.showMessageDialog(null, "A potência é: " + p);
     }

    public static int potencia(int b, int e) // def potencia(b,e):
    {
        int pot = 1;
        for (int i = 1; i <= e; i++)
            pot = pot * b;
        return pot;
    }
}
