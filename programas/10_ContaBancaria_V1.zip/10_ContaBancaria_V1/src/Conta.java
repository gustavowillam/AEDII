public class Conta
{
   private
     int agencia; //agencia a qual a conta pertence
     int num_conta; // numero da conta 
     double saldo; // saldo atual da conta
 
   public Conta( ) //construtor default da classe
     {
        setConta(0, 0, 0); 
     }

   //métodos set

   public void setConta(int a, int nc, double s)
   {
      agencia = a; 
      num_conta = nc; 
      saldo = s; 
   } 
   public void setAgencia(int ag)  //configurar a agencia
   {
      if ( ag < 0 )   agencia = 0;
      else   agencia = ag; 
   }

   public void setNum_Conta(int nc) //configurar o nr. conta
   {
      if (nc < 0)   num_conta = 0; 
      else   num_conta = nc; 
   }

   public void setSaldo(double s)  //configurar o saldo
   {
      saldo = s; 
   }
   //métodos get
   public int getAgencia( )
   {
      return agencia; 
   }
   public int getNum_Conta( ) 
   {
      return num_conta; 
   }
   public double getSaldo( )
   {
      return saldo; 
   }
   public void Deposito(double valor)
   {
      saldo = saldo + valor; 
   }
   public void Saque(double valor)
   {
      saldo = saldo - valor; 
   }

}