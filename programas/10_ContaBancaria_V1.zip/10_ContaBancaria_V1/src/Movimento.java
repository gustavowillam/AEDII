import javax.swing.JOptionPane;

public class Movimento 
{
    public static void main(String[] args) 
    {

        int choice = 0; //contem a escolha do usuário
        double val;  //variável para conter o valor movimentado
        int agenc, ct; //variáveis para conter a agencia e conta
        Conta C1 = new Conta(); 
 
        while (choice != 7)
        {  
           choice = Integer.parseInt(Instrua_Usuario()); 
           switch (choice)
           {
             case 1:
               val = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor a ser depositado")); 
               C1.Deposito(val);   
               break; 
             case 2:
               val = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor a ser sacado")); 
               C1.Saque(val);   
               break;
             case 3:
               val = C1.getSaldo();                 
               JOptionPane.showMessageDialog(null, "Saldo de :" + val);
               break;
             case 4: 
               JOptionPane.showMessageDialog(null, "Número da Conta  : " + C1.getNum_Conta() + 
                                                                 "\nNúmero da Agência: " + C1.getAgencia() + 
                                       "\nSaldo da Conta   : " + C1.getSaldo());
                break;
             case 5:
               agenc = Integer.parseInt(JOptionPane.showInputDialog(null,  "Digite o numero da agência")); 
               C1.setAgencia(agenc);   
               break;
 
             case 6:
               ct = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite o numero da conta")); 
               C1.setNum_Conta(ct);   
               break;
 
             case 7:
               break;
 
             default:
             JOptionPane.showMessageDialog(null, "Opção inválida" );    
           }
        }
  
    }

    public static  String Instrua_Usuario()
    {
       String input;
       input = JOptionPane.showInputDialog(null, "Tecle 1 para Depositar \n" +
                "Tecle 2 para Sacar \n" +
                "Tecle 3 para Saldo\n" + 
                "Tecle 4 para Informações da conta \n" + 
                "Tecle 5 para Alterar agência \n" + 
                "Tecle 6 para Alterar conta \n" + 
                "Tecle 7 para Sair");
 
       return input; 

    }  //fim do método 

}
