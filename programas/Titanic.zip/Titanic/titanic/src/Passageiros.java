public class Passageiros {
    String nome, pais;
    double valor, peso;
    int idade;
}
