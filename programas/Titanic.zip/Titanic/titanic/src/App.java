import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {
        List<Passageiros> L = new ArrayList<Passageiros>();
        int op = -1;
        while (op != 0) {
            op = Integer.parseInt(JOptionPane.showInputDialog(null,
                    "1 - Cadastre o passageiro \n" +
                            "2 - Pesquisar por nome \n" +
                            "3 - Pesquisar por país \n" +
                            "4 - Listagem de passageiros \n" +
                            "0 - Sair do programa \n" +
                            "Digite o número da opção"));

            if (op == 1) {
                Passageiros p = new Passageiros();
                p.nome = JOptionPane.showInputDialog(null, "Digite o nome: ");
                p.pais = JOptionPane.showInputDialog(null, "Digite o país: ");
                p.idade = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a idade: "));
                p.peso = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o peso: "));
                p.valor = 50000;
                if (p.idade >= 60 || p.idade < 18) {
                    p.valor = p.valor / 2;
                }
                if (p.peso > 70) {
                    p.valor = p.valor * 1.05;
                }
                L.add(p);
            }
            if (op == 2) {
                String n;
                n = JOptionPane.showInputDialog(null, "Pesquise o nome: ");
                for (int i = 0; i < L.size(); i++) {
                    if (n.equals(L.get(i).nome)) {
                        JOptionPane.showMessageDialog(null,
                                "\n Nome: " + L.get(i).nome +
                                        "\n País: " + L.get(i).pais +
                                        "\n Idade: " + L.get(i).idade +
                                        "\n Peso: " + L.get(i).peso +
                                        "\n Valor: " + L.get(i).valor);
                    }
                }

            }
            if (op == 3) {
                String n;
                n = JOptionPane.showInputDialog(null, "Pesquise o país: ");
                for (int i = 0; i < L.size(); i++) {
                    if (n.equals(L.get(i).pais)) {
                        JOptionPane.showMessageDialog(null,
                                "\n Nome: " + L.get(i).nome +
                                        "\n País: " + L.get(i).pais +
                                        "\n Idade: " + L.get(i).idade +
                                        "\n Peso: " + L.get(i).peso +
                                        "\n Valor: " + L.get(i).valor);
                    }
                }
            }
            if (op == 4) {
                for (int i = 0; i < L.size(); i++) {
                    JOptionPane.showMessageDialog(null,
                            "\n Nome: " + L.get(i).nome +
                                    "\n País: " + L.get(i).pais +
                                    "\n Idade: " + L.get(i).idade +
                                    "\n Peso: " + L.get(i).peso +
                                    "\n Valor: " + L.get(i).valor);

                }

            }

        }

    }
}
