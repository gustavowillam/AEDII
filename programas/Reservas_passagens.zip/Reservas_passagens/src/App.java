import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class App {

    public static void main(String[] args) {

        List<Voo> L = new ArrayList<Voo>();
        int op = -1;

        while (op != 5) {
            op = Integer.parseInt(JOptionPane.showInputDialog(null,
                    "1 - Cadastre um voo \n" +
                            "2 - Reservar um ou vários assentos \n" +
                            "3 - Total vendido \n" +
                            "4 - Listagem \n" +
                            "5 - Sair do programa \n" +
                            "Digite a opção desejada"));

            if (op == 1) { // Cadastrar voo

                Voo v = new Voo();
                v.setNum_voo(Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o número do voo")));
                v.setOrigem(JOptionPane.showInputDialog(null, "Digite a cidade de origem"));
                v.setDestino(JOptionPane.showInputDialog(null, "Digite a cidade de destino"));
                v.setData(JOptionPane.showInputDialog(null, "Informe a data da partida"));
                v.setHora(JOptionPane.showInputDialog(null, "Informe o horário da partida"));
                v.setN_assento(
                        Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o total de assentos do voo")));
                v.setAssentos_dispiniveis(v.getN_assento());
                v.setPreco(Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o preço do assento")));
                L.add(v);
            }

            if (op == 2) { // Reservar assento
                int n_voo = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o número do voo"));
                boolean achei = false;

                while (!achei) {
                    for (int i = 0; i < L.size(); i++) {
                        if (n_voo == L.get(i).getNum_voo()) {
                            achei = true;
                            int qtd = Integer.parseInt(
                                    JOptionPane.showInputDialog(null, "Informe a quantidade de assentos desejada"));
                            while (qtd > L.get(i).getAssentos_dispiniveis()) {
                                JOptionPane.showMessageDialog(null,
                                        "Quantidade superior ao disponível, temos disponíveis:"
                                                + L.get(i).getAssentos_dispiniveis());
                                qtd = Integer.parseInt(
                                        JOptionPane.showInputDialog(null, "Informe a quantidade de assentos desejada"));
                            }
                            int qtd_atual = L.get(i).getAssentos_dispiniveis() - qtd;
                            L.get(i).setAssentos_dispiniveis(qtd_atual);
                            double valor_total = L.get(i).getPreco() * qtd;
                            JOptionPane.showMessageDialog(null, "Valor total a pagar:" + valor_total);
                        }
                        if (!achei) {
                            JOptionPane.showMessageDialog(null,
                                    "Voo não encontrado. Informe o número do voo novamente.");
                            n_voo = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o número do voo"));
                        }
                    }
                }
            }

            if (op == 3) {
                int n_voo = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o número do voo"));
                boolean achei = false;
                double valor = 0;
                for (int i = 0; i < L.size(); i++) {
                    if (L.get(i).getNum_voo() == n_voo) {
                        achei = true;
                        int reservas = L.get(i).getN_assento() - L.get(i).getAssentos_dispiniveis();
                        valor = reservas * L.get(i).getPreco();
                        JOptionPane.showMessageDialog(null, "Assentos Reservados: " +
                                (L.get(i).getN_assento() - L.get(i).getAssentos_dispiniveis()));
                        JOptionPane.showMessageDialog(null, "Preço da passagem: " + L.get(i).getPreco());
                        JOptionPane.showMessageDialog(null, "Valor total das reservas: " + valor);
                    }
                    if (!achei) {
                        JOptionPane.showMessageDialog(null, "Voo não encontrado");
                    }
                }
            }

            if (op == 4) {
                String r = "";
                for (int i = 0; i < L.size(); i++) {
                    r = r + " \n Voo: " + L.get(i).getNum_voo() +
                            " \n Origem: " + L.get(i).getOrigem() +
                            " \n Destino: " + L.get(i).getDestino() +
                            " \n Data Partida: " + L.get(i).getData() +
                            " \n Hora Partida: " + L.get(i).getHora() +
                            " \n Número de assentos: " + L.get(i).getN_assento() +
                            " \n Assentos disponíveis: " + L.get(i).getAssentos_dispiniveis() +
                            " \n Valor do assento  : " + L.get(i).getPreco() + "\n";
                }
                JOptionPane.showMessageDialog(null, r);
            }
        }
    }
}