import javax.swing.JOptionPane;

public class Voo {
    private int num_voo, n_assento, assentos_dispiniveis;
    private String origem, destino, data, hora;
    private double preco;

    public Voo() {
        num_voo = 0;
        n_assento = 0;
        assentos_dispiniveis = n_assento;
        origem = "";
        destino = "";
        data = "";
        hora = "";
        preco = 0.0;
    }

    public int getNum_voo() {
        return num_voo;
    }

    public void setNum_voo(int num_voo) {
        this.num_voo = num_voo;
    }

    public int getN_assento() {
        return n_assento;
    }

    public void setN_assento(int n_assento) {
        this.n_assento = n_assento;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        while (destino.equals(origem)) {
            JOptionPane.showMessageDialog(null, "O destino não pode ser o mesmo da Origem");
            destino = JOptionPane.showInputDialog(null, "Digite a cidade de destino novamente");
        }
        this.destino = destino;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        if (preco < 0)
            JOptionPane.showMessageDialog(null, " Preço tem que ser maior que 0");
        else
            this.preco = preco;
    }

    public int getAssentos_dispiniveis() {
        return assentos_dispiniveis;
    }

    public void setAssentos_dispiniveis(int assentos_dispiniveis) {
        this.assentos_dispiniveis = assentos_dispiniveis;
    }

}