<?php 

session_start();
if(!isset($_SESSION['chat_history'])){
    $_SESSION['chat_history'] = array();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Introdução ao GPT</title>
</head>
<body>
    <h1>Chat Com GPT<h1>
        <div id="chat-container">
            <?php
            if(!empty($_SESSION['chat_history'])){
                foreach ($_SESSION['chat_history'] as $entry) {
                    echo '<div class="message '.$entry['sender'].'">'
                    .$entry['message'] .'</div>';
                }
            }
            ?>
        </div>
        <form method="post" action="">
        <label for="user_input">Digite sua pergunta ?</label><br>
        <input type="text" id="user_input" name="user_input" ><br><br>
        <input type="submit" value="Enviar">
        </form>
</body>
</html>