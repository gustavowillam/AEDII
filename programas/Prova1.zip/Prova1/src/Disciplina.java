public class Disciplina {
    private String nome_disciplina;
    private Integer nr_aulas;

    public String getNome_disciplina() {
        return nome_disciplina;
    }
    public void setNome_disciplina(String nome_disciplina) {
        this.nome_disciplina = nome_disciplina;
    }
    public Integer getNr_aulas() {
        return nr_aulas;
    }
    public void setNr_aulas(Integer nr_aulas) {
        this.nr_aulas = nr_aulas;
    }
}
