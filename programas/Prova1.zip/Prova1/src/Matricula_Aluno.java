import javax.swing.JOptionPane;

public class Matricula_Aluno {
    private Aluno aluno;
    private Disciplina disciplina;
    private Double nota_1;
    private Double nota_2;
    private Double nota_3;
    private Double media;
    private Integer nr_faltas;
    private String situacao;

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    public Double getNota_1() {
        return nota_1;
    }

    public void setNota_1(Double nota_1) {
        while (nota_1 < 0 || nota_1 > 10) {
            JOptionPane.showMessageDialog(null, "Nota deve estar entre 0 e 10");
            nota_1 = Double.parseDouble(JOptionPane.showInputDialog("Digite a primeira nota"));
        }

        this.nota_1 = nota_1;
    }

    public Double getNota_2() {
        return nota_2;
    }

    public void setNota_2(Double nota_2) {
        while (nota_2 < 0 || nota_2 > 10) {
            JOptionPane.showMessageDialog(null, "Nota deve estar entre 0 e 10");
            nota_2 = Double.parseDouble(JOptionPane.showInputDialog("Digite a segunda nota"));
        }

        this.nota_2 = nota_2;
    }

    public Double getNota_3() {
        return nota_3;
    }

    public void setNota_3(double nota_3) {

        while (nota_3 < 0 || nota_3 > 10) {
            JOptionPane.showMessageDialog(null, "Nota deve estar entre 0 e 10");
            nota_3 = Double.parseDouble(JOptionPane.showInputDialog("Digite a terceira nota"));
        }
        this.nota_3 = nota_3;
    }

    public Double getMedia() {
        return media;
    }

    public void setMedia() {
        this.media = (nota_1 + nota_2 + nota_3) / 3;
    }

    public Integer getNr_faltas() {
        return nr_faltas;
    }

    public void setNr_faltas(Integer nr_faltas) {
        this.nr_faltas = nr_faltas;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao() {
        if (media >= 6 && nr_faltas <= 0.25 * disciplina.getNr_aulas())
            this.situacao = "Aprovado";

        if (media < 6 && nr_faltas <= 0.25 * disciplina.getNr_aulas())
            this.situacao = "Reprovado por média";

        if (media >= 6 && nr_faltas > 0.25 * disciplina.getNr_aulas())
            this.situacao = "Reprovado por falta";

        if (media < 6 && nr_faltas > 0.25 * disciplina.getNr_aulas())
            this.situacao = "Reprovado por média e falta";
    }

}
