import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {
        List<Aluno> LA = new ArrayList<Aluno>();
        List<Disciplina> LD = new ArrayList<Disciplina>();
        List<Matricula_Aluno> LM = new ArrayList<Matricula_Aluno>();
        int opcao = -1;

        while (opcao != 6) {
            opcao = Integer.parseInt(
                    JOptionPane.showInputDialog(
                            "\n 1- Cadastrar Aluno" +
                                    "\n 2- Cadastrar Disciplina" +
                                    "\n 3- Realizar Matrícula" +
                                    "\n 4- Histórico do Aluno" +
                                    "\n 5- Pesquisar Disciplina" +
                                    "\n 6- Sair do Programa"));

            if (opcao == 1) {
                Aluno a = new Aluno();
                a.setMatricula(JOptionPane.showInputDialog("Digite o número da matrícula"));
                a.setNome(JOptionPane.showInputDialog("Digite o nome do aluno"));
                a.setCurso(JOptionPane.showInputDialog("Digite o curso do aluno"));
                LA.add(a);
            }

            if (opcao == 2) {
                Disciplina d = new Disciplina();
                d.setNome_disciplina(JOptionPane.showInputDialog("Digite o nome da disciplina"));
                d.setNr_aulas(Integer.parseInt(JOptionPane.showInputDialog("Digite o número de aulas")));
                LD.add(d);
            }

            if (opcao == 3) {
                Matricula_Aluno m = new Matricula_Aluno();
                int pos = pesquisa_aluno(LA);
                if (pos >= 0) {
                    m.setAluno(LA.get(pos));
                } else
                    JOptionPane.showMessageDialog(null, "Aluno não cadastrado");

                int posi = pesquisa_disciplina(LD);
                if (posi >= 0) {
                    m.setDisciplina(LD.get(posi));
                } else
                    JOptionPane.showMessageDialog(null, "Disciplina não cadastrada");
                m.setNota_1(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite a primeira nota")));
                m.setNota_2(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite a segunda nota")));
                m.setNota_3(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite a terceira nota")));
                m.setMedia();
                m.setNr_faltas(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o número de faltas")));
                m.setSituacao();
                LM.add(m);
            }

            if (opcao == 4) {
                String nome_aluno = JOptionPane.showInputDialog("Digite o nome do aluno para pesquisar");
                String r = "";
                for (int i = 0; i < LM.size(); i++) {
                    if (nome_aluno.equals(LM.get(i).getAluno().getNome())) {
                        r = r + "\n Nome Aluno : " + LM.get(i).getAluno().getNome() +
                                "\n Matrícula : " + LM.get(i).getAluno().getMatricula() +
                                "\n Nome Curso : " + LM.get(i).getAluno().getCurso() +
                                // "\n Nome Disciplina" + LD.get(i).getNome_disciplina() +
                                "\n Média : " + LM.get(i).getMedia() +
                                "\n Número de faltas : " + LM.get(i).getNr_faltas() +
                                "\n Situação : " + LM.get(i).getSituacao();
                    }
                }
                if (!r.equals(""))
                    JOptionPane.showMessageDialog(null, r);
                else
                    JOptionPane.showMessageDialog(null, "Aluno não cadastrado!");
            }

            if (opcao == 5) {
                String nome_disc = JOptionPane.showInputDialog("Digite o nome da disciplina para pesquisar");
                String res = "";
                for (int i = 0; i < LM.size(); i++) {
                    if (nome_disc.equals(LM.get(i).getDisciplina().getNome_disciplina())) {
                        res = res + "\n Número de aulas: " + LM.get(i).getDisciplina().getNr_aulas() +
                                "\n Aluno : " + LM.get(i).getAluno().getNome() +
                                "\n Média : " + LM.get(i).getMedia() +
                                "\n Número de faltas : " + LM.get(i).getNr_faltas() +
                                "\n Situação : " + LM.get(i).getSituacao();
                                // "\n Nome Da Disciplina : " + LD.get(i).getNome_disciplina() +;
                    }
                }
                if (!res.equals(""))
                    JOptionPane.showMessageDialog(null, res);
                else
                    JOptionPane.showMessageDialog(null, "Disciplina não cadastrada!");
            }
        }
    }

    public static int pesquisa_aluno(List<Aluno> LA) {
        String al = JOptionPane.showInputDialog("Digite o nome do aluno");
        for (int i = 0; i < LA.size(); i++) {
            if (al.equals(LA.get(i).getNome())) {
                return i;
            }
        }
        return -1;
    }

    public static int pesquisa_disciplina(List<Disciplina> LD) {
        String di = JOptionPane.showInputDialog("Digite o nome da disciplina");
        for (int i = 0; i < LD.size(); i++) {
            if (di.equals(LD.get(i).getNome_disciplina())) {
                return i;
            }
        }
        return -1;
    }
}
