import javax.swing.JOptionPane;

public class App 
{
    public static void main(String[] args) 
    {
        // System.out.println("Hello, World!");
        //JOptionPane.showMessageDialog(null, "Hello World");
        int x, y, z;  
        //x = int(input('Digite X')) -> código python  
        x = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o valor de X"));
        y = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o valor de Y"));
        z = x + y;
        JOptionPane.showMessageDialog(null, "A soma é: " + z);
    }
}
