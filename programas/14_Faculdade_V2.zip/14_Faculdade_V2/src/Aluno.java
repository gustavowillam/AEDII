
import javax.swing.JOptionPane;

public class Aluno  extends Pessoa
{
   private String Forma_Ingresso; 
   private Curso cur;

   public Aluno() 
   {
   }

   public Aluno(String nome, String rG, String forma_Ingresso, Curso cur) {
    super(nome, rG);
    Forma_Ingresso = forma_Ingresso;
    this.cur = cur;
   }


   public String getForma_Ingresso() 
   {
    return Forma_Ingresso;
   }

   public void setForma_Ingresso(String forma_Ingresso) 
   {
        Forma_Ingresso = forma_Ingresso;
   }

   public Curso getCur() 
   {
     return cur;
   }

   public void setCur(Curso cur) 
   {
      this.cur = cur;
   }




public void Set_Cadastro()  //solicitar os dados da classe 
{
    //preenchendo os atributos do curso 
    String nomecur; 
    nomecur = JOptionPane.showInputDialog(null, "Digite o nome do curso"); 
    String area; 
    area = JOptionPane.showInputDialog(null, "Digite a area do curso"); 
    Curso c = new Curso(nomecur, area); 
    setCur(c);    


    //preenchendo os atributos da classe Pessoa
    setNome(JOptionPane.showInputDialog(null, "Digite o nome do aluno"));
    setRG(JOptionPane.showInputDialog(null, "Digite o RG do aluno"));   

    //preenchendo os atributos da classe Aluno
    setForma_Ingresso(JOptionPane.showInputDialog(null, "Digite a forma de Ingresso do aluno"));   

}

public String Print_Cadastro()
{
    String p; 
    p = "Nome do Aluno:     " + getNome() + "\n" + 
        "RG do Aluno:       " + getRG() + "\n" +
        "Forma de Ingresso: " + getForma_Ingresso()  + "\n" +
        "Curso do Aluno  :  " + getCur().getNomeCurso() + "\n" + 
        "Area do Curso:     " + getCur().getArea(); 

    return p;     
}







   
}
