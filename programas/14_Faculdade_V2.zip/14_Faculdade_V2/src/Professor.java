import javax.swing.JOptionPane;

public class Professor  extends Pessoa
{
   private String Titulacao;

public Professor() 
{
    
}

public Professor(String nome, String rG, String titulacao) {
    super(nome, rG);
    Titulacao = titulacao;
} 

public String getTitulacao() {
    return Titulacao;
}

public void setTitulacao(String titulacao) {
    Titulacao = titulacao;
}



public void Set_Cadastro()  //solicitar os dados da classe 
{

    //preenchendo os atributos da classe Pessoa
    setNome(JOptionPane.showInputDialog(null, "Digite o nome do professor"));
    setRG(JOptionPane.showInputDialog(null, "Digite o RG do professor"));   

    //preenchendo os atributos da classe Professor
    setTitulacao(JOptionPane.showInputDialog(null, "Digite a titulação do professor"));   

}

public String Print_Cadastro()
{
    String p; 
    p = "Nome do Professor: " + getNome() + "\n" + 
        "RG do Professor:   " + getRG() + "\n" +
        "Titulação:         " + getTitulacao(); 

    return p;     
}


}
