public class Curso
{
    private String NomeCurso; 
    private String Area;

    public Curso()
    {
    }
    public Curso(String nomeCurso, String area) 
    {
        NomeCurso = nomeCurso;
        Area = area;
    }
    public String getNomeCurso() {
        return NomeCurso;
    }
    public void setNomeCurso(String nomeCurso) {
        NomeCurso = nomeCurso;
    }
    public String getArea() {
        return Area;
    }
    public void setArea(String area) {
        Area = area;
    }     
}
