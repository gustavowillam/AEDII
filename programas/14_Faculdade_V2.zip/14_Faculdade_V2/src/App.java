import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class App 
{
    public static void main(String[] args) 
    {

        List<Pessoa> pessoas = new ArrayList<Pessoa>(); 
         
        int opcao = 0, opcao2 = 0;  

        while (opcao != 4)
        {
           opcao = Integer.parseInt(JOptionPane.showInputDialog(null, 
                  "1-Cadastrar Pessoa\n" + 
                  "2-Pesquisar Pessoa\n" + 
                  "3-Listagem de Pessoas Cadastrados\n" + 
                  "4-Sair do programa")); 

           switch(opcao)
           {
              case 1: //cadastrar pessoa

                opcao2 = 0; 
                while (opcao2 != 4)
                {
                  opcao2 = Integer.parseInt(JOptionPane.showInputDialog(null, 
                        "1-Cadastrar Professor\n" + 
                        "2-Cadastrar Aluno\n" + 
                        "3-Cadastrar Funcionario\n" + 
                        "4-Voltar ao menu principal")); 
                                
                        switch(opcao2)
                        {
                            case 1:  //cadastrar professor
                               Professor p = new Professor(); 
                               p.Set_Cadastro(); 
                               pessoas.add(p); 
                            break; 

                            case 2:  //cadastrar aluno
                               Aluno a = new Aluno(); 
                               a.Set_Cadastro();
                               pessoas.add(a); 
                            break; 

                            case 3:  //cadastrar funcionoario
                               Funcionario f = new Funcionario(); 
                               f.Set_Cadastro();
                               pessoas.add(f); 
                            break; 

                            case 4: 
                            break; 

                            default: 
                            JOptionPane.showMessageDialog(null, "Opção Inválida.");  

                        }
                }

              break; 

              case 2:  //pesquisar pessoa
                pesquisa_pessoa(pessoas); 

              break; 

              case 3:  //listagem de pessoas cadastradas
                 String pe; 
                 if  (pessoas.size() > 0)
                    for (int i = 0; i < pessoas.size(); i++)
                    {
                        pe = pessoas.get(i).Print_Cadastro(); 
                        JOptionPane.showMessageDialog(null, pe); 
                    }
                 else 
                     JOptionPane.showMessageDialog(null, "Nenhuma pessoa cadastrada.");     

              break; 
              
              
              case 4:  //sair do programa
              break; 

              default: 
                 JOptionPane.showMessageDialog(
                    null, "Opção Inválida.");  

           }  //fim do switch

        }  //fim do while 

    }  //fim do método main 
    
    public static void pesquisa_pessoa(List<Pessoa> pessoas)
    {
        String RG_pessoa;   
        RG_pessoa = JOptionPane.showInputDialog(null, "Digite o RG a ser pesquisado:"); 


        for (int i = 0; i < pessoas.size(); i++)
        {
            String pe; 
            if (RG_pessoa.equals(pessoas.get(i).getRG() )) 
            {
                 pe = pessoas.get(i).Print_Cadastro();   
                
                 JOptionPane.showMessageDialog(null,  pe);
                 
            }
        }
    }


}  //fim da classe App
