public abstract class Pessoa 
{
    private String nome; 
    private String RG; 
    

    public Pessoa() {
    }

    public Pessoa(String nome, String rG) {
        this.nome = nome;
        RG = rG;
    }

    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRG() {
        return RG;
    }

    public void setRG(String rG) {
        RG = rG;
    }

    public abstract void Set_Cadastro();   //solicitar a entrada dos dados 

    public abstract String Print_Cadastro();   //exibe os atributos da classe 

    
}
