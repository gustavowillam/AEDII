import javax.swing.JOptionPane;

public class Funcionario  extends Pessoa
{
    private String setor; 


    public Funcionario()
    {
    }

 
    public Funcionario(String nome, String rG, String setor) {
        super(nome, rG);
        this.setor = setor;
    }


    public String getSetor() {
        return setor;
    }


    public void setSetor(String setor) {
        this.setor = setor;
    }


    public void Set_Cadastro()  //solicitar os dados da classe 
    {
    
        //preenchendo os atributos da classe Pessoa
        setNome(JOptionPane.showInputDialog(null, "Digite o nome do Funcionario"));
        setRG(JOptionPane.showInputDialog(null, "Digite o RG do Funcionario"));   
    
        //preenchendo os atributos da classe Professor
        setSetor(JOptionPane.showInputDialog(null, "Digite o setor do Funcionario"));   
    
    }
    
    public String Print_Cadastro()
    {
        String p; 
        p = "Nome do Funcionario: " + getNome() + "\n" + 
            "RG do Funcionario:   " + getRG() + "\n" +
            "Setor do Funcionario:" + getSetor(); 
    
        return p;     
    }


        
    
}
