import javax.swing.JOptionPane;

public class App 
{
    public static void main(String[] args) 
    {
        Conta c = new Conta(); 
        String ag, nc; 
        ag = JOptionPane.showInputDialog(
            null, "Digite a agência"); 
        nc = JOptionPane.showInputDialog(
                null, "Digite a conta"); 
    
        c.cadastrar(ag, nc, 100);

        c.deposito(Double.parseDouble(JOptionPane.showInputDialog(
            null, "Digite o valor do deposito")));

        JOptionPane.showMessageDialog(
            null, "Saldo: " + (c.get_saldo()+c.get_limite())); 
   
        c.saque(Double.parseDouble(JOptionPane.showInputDialog(
            null, "Digite o valor do saque")));

        JOptionPane.showMessageDialog(
            null, "Saldo: " + (c.get_saldo()+c.get_limite())); 

        c.saque(Double.parseDouble(JOptionPane.showInputDialog(
            null, "Digite o valor do saque")));

        JOptionPane.showMessageDialog(
            null, "Saldo: " + (c.get_saldo()+c.get_limite())); 

    }
}
