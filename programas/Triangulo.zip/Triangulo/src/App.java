import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {
        double A, B, C;
        A = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o valor de A"));
        B = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o valor de B"));
        C = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o valor de C"));
        // testar se os lados formam triângulo
        if ((A < B + C) && (B < A + C) && (C < A + B)) // se for True -> é Triângulo
        {
            if (A == B && B == C)
                JOptionPane.showMessageDialog(null, "Triângulo Equilátero");
            else {
                if ((A == B) || (A == C) || (B == C))
                    JOptionPane.showMessageDialog(null, "Triângulo Isóceles");
                else
                    JOptionPane.showMessageDialog(null, "Triângulo Escaleno");
            }
        } else
            JOptionPane.showMessageDialog(null, "os Lados digitados não forma triângulo");
    }
}
