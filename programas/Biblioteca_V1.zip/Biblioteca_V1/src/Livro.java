import javax.swing.JOptionPane;

public class Livro {

    private String titulo;
    private String autor;
    private int ano;
    private boolean emprestado;

    public Livro() {

        titulo = ""; // pode fazer sem essas informacoes
        autor = "";
        emprestado = false;
    }

    // esse construtor tem os parâmetros para serem usados, quando for aocar a
    // memória.
    public Livro(String titulo, String autor, int ano) {

        this.titulo = titulo;
        this.autor = autor;
        this.ano = ano;
        emprestado = false;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        if (ano < 0) {
            JOptionPane.showMessageDialog(null, "Ano Inválido");
        }
        this.ano = ano;
    }

    // booleano abriu isEmprestado mas pode mudar para getEmprestado.
    public boolean getEmprestado() {
        return emprestado;
    }

    public void setEmprestado(boolean emprestado) {
        this.emprestado = emprestado;
    }

    public String toString() {
        String s = "";
        s = "\n Titulo: " + titulo +
                "\n Autor: " + autor +
                "\n Ano: " + ano;
        if (emprestado == false)
            s = s + "\n Status: Disponível";
        else
            s = s + "\n Status: Emprestado";

        return s;
    }

}
