import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {

        List<Livro> L = new ArrayList<Livro>();

        int op = 0;
        String t;
        boolean achei;

        while (op != 5) {
            op = menu();
            switch (op) {

                case 1: // cadastrar Livro
                    Livro livro = new Livro();
                    livro.setTitulo(JOptionPane.showInputDialog("Título"));
                    livro.setAutor(JOptionPane.showInputDialog("Autor"));
                    livro.setAno(Integer.parseInt(JOptionPane.showInputDialog("Ano")));
                    L.add(livro);
                    break;
                case 2: // emprestimo
                    t = JOptionPane.showInputDialog("Título");
                    achei = false;
                    for (int i = 0; i < L.size(); i++) {
                        if (t.equals(L.get(i).getTitulo())) {
                            achei = true;
                            if (L.get(i).getEmprestado() == false)
                                L.get(i).setEmprestado(true);
                            else
                                JOptionPane.showMessageDialog(null, "Livro Indisponível");
                        }
                    }
                    if (achei == false)
                        JOptionPane.showMessageDialog(null, "Livro não encontrado");
                    break;
                case 3: // devolução
                    t = JOptionPane.showInputDialog("Título");
                    achei = false;
                    for (int i = 0; i < L.size(); i++) {
                        if (t.equals(L.get(i).getTitulo())) {
                            achei = true;
                            if (L.get(i).getEmprestado() == true)
                                L.get(i).setEmprestado(false);
                            else
                                JOptionPane.showMessageDialog(null, "Livro disponível");
                        }
                    }
                    if (achei == false)
                        JOptionPane.showMessageDialog(null, "Livro não encontrado");
                    break;
                case 4: // Listagem
                    String acervo = "";
                    for (int i = 0; i < L.size(); i++) {
                        acervo = acervo + L.get(i).toString() + "\n";
                    }
                    JOptionPane.showMessageDialog(null, acervo);
                    break;
                case 5: // sair do programa
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção Inválida.");

            }
        }

    }

    public static int menu() {
        int op;
        op = Integer.parseInt(JOptionPane.showInputDialog(
                "1-Cadastrar Livro \n" +
                        "2- Emprestimo \n" +
                        "3- Devolucao \n" +
                        "4- Listagem de Livros disponíveis \n" +
                        "5- Sair do programa "));
        return op;
    }
}
