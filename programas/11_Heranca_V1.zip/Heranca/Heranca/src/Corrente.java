import javax.swing.JOptionPane;

public class Corrente extends Conta 
{
    private double limite;

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }
    
    public Corrente(String agencia, String numero, double limite) {
        super(agencia, numero);
        this.limite = limite;
    } 

    public void saque(double valor)
    {
        if (valor <= limite + getSaldo()) 
           super.saque(valor);
        else 
           JOptionPane.showMessageDialog(
               null, "Saldo Insuficiente.");   
    }
    

}
