import javax.swing.JOptionPane;

public class App 
{
    public static void main(String[] args) 
    {
        String ag = "123"; 
        String nr = "111222"; 
        double limite = 1000.0; 
        Corrente cc = new Corrente(ag, nr, limite); 

        ag = "123"; 
        nr = "999888"; 
        double tx = 0.7; 
        Poupanca cp = new Poupanca(ag, nr, tx); 

        
    }
}
