public class Conta 
{
    private String agencia, numero; 
    private double saldo;
   
    public Conta(String agencia, String numero)
    {
        this.agencia = agencia;
        this.numero = numero;
        this.saldo = 0;
    }
    public String getAgencia() {
        return agencia;
    }
    public String getNumero() {
        return numero;
    }
    public double getSaldo() {
        return saldo;
    }
    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }
    public void setNumero(String numero) {
        this.numero = numero;
    }
    public void deposito(double valor)
    {
        this.saldo = this.saldo + valor; 
    }   
    public void saque (double valor)
    {
        saldo = saldo - valor; 
    }
}
