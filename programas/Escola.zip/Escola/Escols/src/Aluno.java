public class Aluno {
    int matricula;
    String nome;
    String curso;
}
