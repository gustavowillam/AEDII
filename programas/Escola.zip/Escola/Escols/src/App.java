import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {

        List<Aluno> L = new ArrayList<Aluno>();

        for (int i = 1; i <= 2; i++) {
            Aluno a = new Aluno();
            a.matricula = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a Matricula"));
            a.nome = JOptionPane.showInputDialog(null, "Digite o nome");
            a.curso = JOptionPane.showInputDialog(null, "Digite o curso");
            L.add(a);
        }
        String r = "";
        for (int i = 0; i < L.size(); i++) {
            r = r + "Matricula: " + L.get(i).matricula + "\n" +
                    "Nome: " + L.get(i).nome + "\n" +
                    "Curso: " + L.get(i).curso + "\n\n";
        }
        JOptionPane.showMessageDialog(null, r); // L[i].matricula

    }
}

/*
 * Aluno a = new Aluno();
 * 
 * a.matricula = 123;
 * a.nome = "Joao";
 * a.curso = "GTI";
 */

/*
 * List<Integer> L = new ArrayList<Integer>(); // L = []
 * 
 * int x = 10;
 * L.add(x); // L.append(x)
 * 
 * int y = 2;
 * L.add(y); // L.append(y)
 * 
 * int px;
 * px = L.indexOf(x); // L.indexOf(x)
 * JOptionPane.showMessageDialog(null, x + " posição: " + px);
 * 
 * int py;
 * py = L.indexOf(y); // L.indexOf(x)
 * JOptionPane.showMessageDialog(null, y + " posição: " + py);
 * 
 * if (L.contains(x)) // if L.contains(x): ou if x in L:
 * JOptionPane.showMessageDialog(null, x + " está na Lista");
 * else
 * JOptionPane.showMessageDialog(null, x + " não está na Lista");
 * 
 * Collections.sort(L); // L.sort()
 * 
 * JOptionPane.showMessageDialog(null, L); // print(L)
 * 
 * for (int i = 0; i < L.size(); i++) // for i in range(0, len(L))
 * JOptionPane.showMessageDialog(null, L.get(i)); // print(L[i])
 * 
 */
