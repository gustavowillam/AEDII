import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) throws Exception {

        int op = -1;
        int n;
        while (op != 0) {
            op = Integer.parseInt(menu());
            switch (op) {
                case 1: // Fatorial
                    n = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite N"));
                    int f = 1;
                    for (int i = 1; i <= n; i++)
                        f = f * i;
                    JOptionPane.showMessageDialog(null, "O fatorial é: " + f);
                    break;
                case 2: // Potencia
                    double b = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite a base"));
                    double e = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite a expoente"));
                    double pot = Math.pow(b, e);
                    JOptionPane.showMessageDialog(null, "A potencia é: " + pot);
                    break;
                case 3: // tabuada
                    n = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite N"));
                    String tab = "";
                    for (int i = 0; i <= 10; i++)
                        tab = tab + n + " * " + i + " = " + n * i + "\n";
                    JOptionPane.showMessageDialog(null, tab);
                    break;
                case 4: // fibonacci
                    n = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite N"));
                    int ant1 = 1;
                    int ant2 = 0;
                    int fib = 0;
                    for (int i = 2; i <= n; i++) {
                        fib = ant1 + ant2;
                        ant2 = ant1;
                        ant1 = fib;
                    }
                    JOptionPane.showMessageDialog(null, "O Fibonacci  é: " + fib);
                    break;
                case 0:

                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção Inválida.");
            }
        }
    } // fim da função main

    public static String menu() // def menu():
    {
        String opcao;
        opcao = JOptionPane.showInputDialog(null, "1-Fatorial \n" +
                "2-Potencia \n" +
                "3-Tabuada  \n" +
                "4-Fibonacci \n" +
                "0-Sair do Programa");
        return opcao;
    }
}
