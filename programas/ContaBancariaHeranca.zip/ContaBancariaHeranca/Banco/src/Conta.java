public class Conta {
    private String agencia;
    private String nr_conta;
    protected double saldo;

    public Conta() {
        saldo = 0;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public String getNr_conta() {
        return nr_conta;
    }

    public void setNr_conta(String nr_conta) {
        this.nr_conta = nr_conta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void deposito(double valor) {
        saldo = saldo + valor;
    }

    public void saque(double valor) {
        saldo = saldo - valor;
    }

    @Override
    public String toString() {
        return "Conta [agencia=" + agencia + ", nr_conta=" + nr_conta + ", saldo=" + saldo + "]";
    }

}
