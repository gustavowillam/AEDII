import javax.swing.JOptionPane;

public class Corrente extends Conta {

    private double limite;

    public Corrente() {
        super();
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }

    public void saque(double valor) {
        if (getSaldo() + limite >= valor)
            super.saque(valor);
        else
            JOptionPane.showMessageDialog(null, "Saldo Insuficiente: " + getSaldo());
    }

    @Override
    public String toString() {
        return super.toString() + "Corrente [limite=" + limite + "]";
    }

}
