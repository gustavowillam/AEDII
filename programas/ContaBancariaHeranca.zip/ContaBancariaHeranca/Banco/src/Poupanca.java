import javax.swing.JOptionPane;

public class Poupanca extends Conta {

    private double tx_rendimento;

    public Poupanca() {
        super(); // chama o construtor da classe base(pai)
    }

    public double getTx_rendimento() {
        return tx_rendimento;
    }

    public void setTx_rendimento(double tx_rendimento) {
        this.tx_rendimento = tx_rendimento;
    }

    public void saque(double valor) {
        if (getSaldo() >= valor)
            super.saque(valor);
        else
            JOptionPane.showMessageDialog(null, "Saldo Insuficiente: " + getSaldo());
    }

    @Override
    public String toString() {
        return super.toString() + "Poupanca [tx_rendimento=" + tx_rendimento + "]";
    }

    public void atualiza_poupanca() {
        saldo = saldo + (tx_rendimento / 100) * saldo;
    }

}
