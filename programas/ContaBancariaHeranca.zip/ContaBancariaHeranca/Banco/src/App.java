import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {

        List<Conta> contas = new ArrayList<Conta>();
        int op = 0;
        while (op != 7) {
            op = Integer.parseInt(JOptionPane.showInputDialog(
                    "\n 1- Abrir conta corrente" +
                            "\n 2- Abrir conta poupança" +
                            "\n 3- Deposito" +
                            "\n 4- Saque" +
                            "\n 5- Exibir Saldo" +
                            "\n 6- Atualizar Poupança" +
                            "\n 7- Sair do Programa"));
            if (op == 1) { // abertura de conta corrente
                Corrente cc = new Corrente();
                cc.setAgencia(JOptionPane.showInputDialog("Digite nr. agência"));
                cc.setNr_conta(JOptionPane.showInputDialog("Digite nr. conta"));
                cc.setLimite(Double.parseDouble(
                        JOptionPane.showInputDialog("Digite limite cheque especial")));
                contas.add(cc);
            }
            if (op == 2) { // abertura de conta poupança
                Poupanca cp = new Poupanca();
                cp.setAgencia(JOptionPane.showInputDialog("Digite nr. agência"));
                cp.setNr_conta(JOptionPane.showInputDialog("Digite nr. conta"));
                cp.setTx_rendimento(Double.parseDouble(
                        JOptionPane.showInputDialog("Digite tx de rendimento")));
                contas.add(cp);
            }
            if (op == 3) { // deposito
                int p = pesquisa(contas);
                if (p >= 0) { // conta existe
                    double valor = Double.parseDouble(
                            JOptionPane.showInputDialog("Digite o valor para deposito"));
                    contas.get(p).deposito(valor);
                } else {
                    JOptionPane.showMessageDialog(null, "Conta Inexistente");
                }
            }
            if (op == 4) { // saque
                int p = pesquisa(contas);
                if (p >= 0) { // conta existe
                    double valor = Double.parseDouble(
                            JOptionPane.showInputDialog("Digite o valor para saque"));
                    contas.get(p).saque(valor);
                } else {
                    JOptionPane.showMessageDialog(null, "Conta Inexistente");
                }
            }
            if (op == 5) { // exibir o saldo
                int p = pesquisa(contas);
                if (p >= 0) { // conta existe
                    JOptionPane.showMessageDialog(null, contas.get(p).toString());
                } else {
                    JOptionPane.showMessageDialog(null, "Conta Inexistente");
                }
            }
            if (op == 6) { // atualiza saldo da conta poupança
                int p = pesquisa(contas);
                if (p >= 0) { // conta existe
                    if (contas.get(p) instanceof Poupanca) { // verificar se a conta na posição p é do tipo poupança
                        // converte contas.get(p) para tipo Poupanca e depois
                        // chama método para aplicar correção monetária.
                        ((Poupanca) contas.get(p)).atualiza_poupanca();
                    } else {
                        JOptionPane.showMessageDialog(null, "Conta pesquisada não é do tipo poupança");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Conta Inexistente");
                }
            }
        } // fim do while
    } // fim do main

    public static int pesquisa(List<Conta> contas) {
        String nc; // pesquisar pelo nr. da conta
        nc = JOptionPane.showInputDialog("Digite o nr. da conta");
        for (int i = 0; i < contas.size(); i++) {
            if (nc.equals(contas.get(i).getNr_conta()))
                return i;
        }
        return -1;
    }
} // fim da classe
