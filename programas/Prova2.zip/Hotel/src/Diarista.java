import javax.swing.JOptionPane;

public class Diarista extends Cliente{
    
    private double valor_diaria;
    private int num_dias;

    

    public double getValor_diaria() {
        return valor_diaria;
    }

    public void setValor_diaria(double valor_diaria) {
        this.valor_diaria = valor_diaria;
    }

    public int getNum_dias() {
        return num_dias;
    }

    public void setNum_dias(int num_dias) {
        this.num_dias = num_dias;
    }
    

    public void Set_Cadastro()  //solicitar os dados da classe 
    {
    
        //preenchendo os atributos da classe Pessoa
        setNome(JOptionPane.showInputDialog(null, "Digite o nome"));
        setTelefone(JOptionPane.showInputDialog(null, "Digite o  telefone"));   
    
        //preenchendo os atributos da classe Professor
        setValor_diaria(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o valor da diária")));  
        setNum_dias(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o número de dias")));  
    
    }
    
    public String Print_Cadastro()
    {
        String p; 
        p = "Cliente Diarista\n"        +
            "\n Nome: " + getNome() + "\n" + 
            "Telefone: " + getTelefone() + "\n" +
            "Valor diária: " + getValor_diaria() + "\n" +
            "Número de dias: " + getNum_dias();
    
        return p;     
    }


}
