import javax.swing.JOptionPane;

public class Mensalista extends Cliente{
    
    private double valor_mensal;
    private String data_vencimento;
   

    public double getValor_mensal() {
        return valor_mensal;
    }
    public void setValor_mensal(double valor_mensal) {
        this.valor_mensal = valor_mensal;
    }
    public String getData_vencimento() {
        return data_vencimento;
    }
    public void setData_vencimento(String data_vencimento) {
        this.data_vencimento = data_vencimento;
    }



    public void Set_Cadastro()  //solicitar os dados da classe 
    {
    
        //preenchendo os atributos da classe Pessoa
        setNome(JOptionPane.showInputDialog(null, "Digite o nome"));
        setTelefone(JOptionPane.showInputDialog(null, "Digite o telefone"));   
    
        //preenchendo os atributos da classe Professor
        setValor_mensal(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o valor mensal")));  
        setData_vencimento(JOptionPane.showInputDialog(null, "Digite a data de vencimento"));  
    
    }
    
    public String Print_Cadastro()
    {
        String p; 
        p = "Cliente Mensalista\n"        +
            "\n Nome: " + getNome() + "\n" + 
            "Telefone: " + getTelefone() + "\n" +
            "Valor mensal: " + getValor_mensal() + "\n" +
            "Data vencimento: " + getData_vencimento();
    
        return p;     
    }
}
