import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args)  {
        
        List<Cliente> clientes = new ArrayList<Cliente>();

        int opcao = -1;  

        while (opcao != 0)
        {

            double TotalD = 0, TotalM = 0;
            int cont_d = 0, cont_m = 0;
            String r;   

            opcao = Integer.parseInt(JOptionPane.showInputDialog(null, 
                  "1- Cadastrar Cliente Mensalista\n" + 
                  "2- Cadastrar Cliente Diarista\n" + 
                  "3- Pesquisar Cliente\n" + 
                  "4- Relatório Gerencial\n" + 
                  "0- Sair")); 

           switch(opcao)
           {
                case 1: //cadastrar mensalista 

                    Mensalista m = new Mensalista(); 
                    m.Set_Cadastro(); 
                    clientes.add(m);

                break;

                case 2: // cadastrar diarista
                    Diarista d = new Diarista();
                    d.Set_Cadastro();
                    clientes.add(d);

                break;

                case 3: // pesquisar cliente
                    pesquisar(clientes);
                break;

                case 4: // Relatório Gerencial
                   
                    r = "Dados clientes: \n"; 

                    for (int i = 0; i < clientes.size(); i++)
                    {
                            
                        if (clientes.get(i) instanceof Diarista) 
                        {
                            cont_d++;

                            r = r      
                            + "\n Nome: " + clientes.get(i).getNome()
                            + "\n Telefone: " + clientes.get(i).getTelefone()
                            + "\n Número de dias hospedados: " + ((Diarista) clientes.get(i)).getNum_dias()
                            + "\n Valor diária: " + ((Diarista) clientes.get(i)).getValor_diaria()
                            + "\n Valor Total: " + ((Diarista) clientes.get(i)).getValor_diaria() * ((Diarista) clientes.get(i)).getNum_dias() + "\n";

                            TotalD = TotalD + ((Diarista) clientes.get(i)).getValor_diaria() * ((Diarista) clientes.get(i)).getNum_dias();
                        
                        }
                    }

                    r = r + "\n Número total de Diaristas: " + cont_d + "\n Lucro Total dos clientes Diaristas " + TotalD; 
                    JOptionPane.showMessageDialog(null, r);
                    

                    r = "Dados clientes: \n"; 
                    
                    for (int i = 0; i < clientes.size(); i++)
                    {

                                            
                        if (clientes.get(i) instanceof Mensalista) {
                            cont_m++;

                            r = r 
                            + "\n Nome: " + clientes.get(i).getNome()
                            + "\n Telefone: " + clientes.get(i).getTelefone()
                            + "\n Data de vencimento - hospedagem: " + ((Mensalista) clientes.get(i)).getData_vencimento()
                            + "\n Valor mensal: " + ((Mensalista) clientes.get(i)).getValor_mensal() + "\n";

                            TotalM = TotalM + ((Mensalista) clientes.get(i)).getValor_mensal();                        
                       
                        }
                    } 
                    r = r + "\n Número total de Mensalistas: " + cont_m + "\n Lucro Total dos clientes Diaristas " + TotalM; 
                    JOptionPane.showMessageDialog(null, r);

                break; 

                
            }

        }

    }

    public static void pesquisar(List<Cliente> clientes)
    {
        String nome_pessoa;  
        boolean achei = false; 
        nome_pessoa = JOptionPane.showInputDialog(null, "Digite o nome do cliente a ser pesquisado: "); 

        for (int i = 0; i < clientes.size(); i++)
        {
            String cli; 
            if (nome_pessoa.equals(clientes.get(i).getNome() )) 
            {
                 cli = clientes.get(i).Print_Cadastro();   
                
                 JOptionPane.showMessageDialog(null,  cli);

                 achei = true;
                 
            }
        }

        if (achei== false) {
            JOptionPane.showMessageDialog(null, "Cliente não encontrado");
        }
    }
}
