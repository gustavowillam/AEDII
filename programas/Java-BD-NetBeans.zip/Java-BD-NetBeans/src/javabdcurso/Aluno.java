/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javabdcurso;


/**
 *
 * @author Gustavo
 */
public class Aluno 
{
    static int ultimo = 0;
    private Integer codigo;
    private String nome;
    private String Telefone;
    private String Email;
    private Curso curso;

    public Aluno () 
    {
    	codigo=0;
    	nome = "";
    	Telefone="";
        Email = "";  
    	curso= new Curso();    	
    }
    public Integer getCodigo() 
    {
    	return codigo;
    }
    public void setCodigo(Integer Codigo)
    {
    	this.codigo = Codigo;
    }
    public String getNome() 
    {
    	return nome;
    }
    public void setNome(String Nome)
    {
    	this.nome = Nome;
    }
    public String getTelefone()
    {
    	return Telefone;
    }
    public void setTelefone(String Telefone)
    {
    	this.Telefone = Telefone;
    }
    public String getEmail()
    {
    	return Email;
    }
    public void setEmail(String Email)
    {
    	this.Email = Email;
    }

    public Curso getCurso() 
    {
    	return curso;
    }
    public void setCurso(Curso curso)
    {
    	this.curso = curso;
    }
    public int incluir(BancoDados BD) 
    {
    	try 
    	{ 		
    		BD.atualizar("INSERT INTO Alunos VALUES ("+codigo+",'"+nome+"' ,'"
    		                     +Telefone+"','"+Email+"',"+curso.getCodigo()+");");
    	} 
    	catch(Exception e) 
    	{
    		e.printStackTrace();
    	}
    	return 1;
    }
    public int alterar(BancoDados BD) 
    {
    	try 
    	{	
    		BD.atualizar("UPDATE Alunos SET Codigo="+codigo+",nome='"+nome+"',Telefone='"
  				+Telefone+"',Email='"+Email+"',codcurso="+curso.getCodigo()
   				+" WHERE Codigo="+codigo);
    	} 
    	catch(Exception e) 
    	{
    		e.printStackTrace();
    	}
    	return 1;
    }
    public void excluir(BancoDados BD)
    {
    	try 
    	{
    		BD.atualizar("DELETE FROM Alunos WHERE codigo="+codigo);
    	} 
    	catch(Exception e) 
    	{
    		e.printStackTrace();
    	}	
    }
}
