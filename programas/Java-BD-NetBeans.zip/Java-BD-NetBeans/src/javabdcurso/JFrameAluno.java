/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * JFrameAluno.java
 *
 * Created on 07/05/2009, 14:43:54
 */

package javabdcurso;

import javax.swing.JOptionPane;

/**
 *
 * @author Gustavo
 */
public class JFrameAluno extends javax.swing.JFrame {

    protected String State; //'INSERT, EDIT, BROWSE'
    protected Aluno aluno;
    protected Curso curso;
    protected BancoDados BD;
    protected Aluno[] a;
    protected Curso[] c;
    protected int RegAtual = 0;
    protected int TotalRegsAluno = 0;
    protected int TotalRegsCurso = 0;

    /** Creates new form JFrameAluno */
    public JFrameAluno()
    {
        initComponents();
    }

    private void StateChange()
    {
       if (State.equals("BROWSE"))
       {
    	  butCadastrar.setEnabled(true);
          butAlterar.setEnabled(true);
          butExcluir.setEnabled(true);
          butFechar.setEnabled(true);
          butConfirmar.setEnabled(false);
          butCancelar.setEnabled(false);
          butPrimeiro.setEnabled(true);
          butAnterior.setEnabled(true);
          butProximo.setEnabled(true);
          butUltimo.setEnabled(true);
       }
       else
       if (State.equals("INSERT") || (State.equals("EDIT")))
       {
     	  butCadastrar.setEnabled(false);
          butAlterar.setEnabled(false);
          butExcluir.setEnabled(false);
          butFechar.setEnabled(false);
          butConfirmar.setEnabled(true);
          butCancelar.setEnabled(true);
          butPrimeiro.setEnabled(false);
          butAnterior.setEnabled(false);
          butProximo.setEnabled(false);
          butUltimo.setEnabled(false);
       }
    }

    private void AtualizaVetorCursos()
    {
       int pos;
       try
       {
           TotalRegsCurso = 0;
           BD.consultar("SELECT * FROM Cursos");
           while(BD.rs.next())
           {
                TotalRegsCurso++;
           }

           if (TotalRegsCurso > 0)
           {
              c = new Curso[TotalRegsCurso+1];
              pos = 1;
              BD.consultar("SELECT * FROM Cursos");
              while(BD.rs.next())
              {
                  c[pos] = new Curso();
                  c[pos].setCodigo(BD.rs.getInt(1));
                  c[pos].setNome(BD.rs.getString(2));
                  pos++;
              }
           }
       }
       catch(Exception e)
       {
           e.printStackTrace();
       }
    }

    private void AtualizaVetorAlunos()
    {
        int pos;
        try
        {
           TotalRegsAluno = 0;
           BD.consultar("SELECT * FROM Alunos");
           while(BD.rs.next())
           {
              TotalRegsAluno++;
           }

           if (TotalRegsAluno > 0)
           {
               a = new Aluno[TotalRegsAluno+1];
               pos = 1;
               BD.consultar("SELECT * FROM Alunos");
               while(BD.rs.next())
               {
                   a[pos] = new Aluno();
                   a[pos].setCodigo(BD.rs.getInt(1));
                   a[pos].setNome(BD.rs.getString(2));
                   a[pos].setTelefone(BD.rs.getString(3));
                   a[pos].setEmail(BD.rs.getString(4));
                   a[pos].setCurso(getCursoVetor("Codigo", BD.rs.getString(5)));
                   pos++;
               }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    private void Localiza(int reg)
    {
        if (TotalRegsAluno > 0)
        {
            if (reg < 1)
                RegAtual = 1;
            else
                if (reg > TotalRegsAluno)
                    RegAtual = TotalRegsAluno;
                else
                    RegAtual = reg;
            editCodigo.setText(Integer.toString(a[RegAtual].getCodigo()));
            editNome.setText(a[RegAtual].getNome());
            editTelefone.setText(a[RegAtual].getTelefone());
            editEmail.setText(a[RegAtual].getEmail());
            jcbCurso.setSelectedItem(a[RegAtual].getCurso().getNome());
        }
        table.getSelectionModel().setSelectionInterval(RegAtual-1, RegAtual-1);
    }


    private void AtualizaGrid()
    {

        int[] l = table.getSelectedRows();//captura as linhas selecionadas

        //pega o DefaultTableModel da tabela
        javax.swing.table.DefaultTableModel dtm =
        (javax.swing.table.DefaultTableModel)table.getModel();

        for(int i = (l.length-1); i >= 0; --i)
        {
            dtm.removeRow(l[i]);//remove todas as linhas selecionadas
        }


        try
        {
                table.setModel(new javax.swing.table.DefaultTableModel(
                               new Object [][] { },
                    //aqui adiciona-se as colunas e seus respectivos nomes
                               new String []   { "Código", "Nome", "Telefone", "Email", "Curso" }   )
                               );

                dtm = (javax.swing.table.DefaultTableModel)table.getModel();
                table.getColumnModel().getColumn(0).setPreferredWidth(100); //codigo
                table.getColumnModel().getColumn(1).setPreferredWidth(200); //nome
                table.getColumnModel().getColumn(2).setPreferredWidth(200); //telefone
                table.getColumnModel().getColumn(3).setPreferredWidth(200); //email
                table.getColumnModel().getColumn(4).setPreferredWidth(300); //curso

                 AtualizaVetorAlunos();
               /*
                if (TotalRegsAluno > 0)
                {
                    for (int i = 1; i<=TotalRegsAluno; i++)
                    {
                        dtm.addRow(new Object[]{
                           a[i].getCodigo(), a[i].getNome(), a[i].getTelefone(), a[i].getEmail(),
                           a[i].getCurso().getNome()});
                    }
                }

                 */

               BD.consultar("SELECT A.codigo, A.nome, A.telefone, A.email, C.Nome " +
                            "FROM Alunos A, Cursos C " +
                            "Where A.CodCurso = C.Codigo");
                while(BD.rs.next())
                {
                    dtm.addRow(new Object[]
                    {
                          BD.rs.getInt(1),BD.rs.getString(2),BD.rs.getString(3),BD.rs.getString(4),BD.rs.getString(5)
                    }         );
                }

        }
        catch(Exception e)
        {
                e.printStackTrace();
        }
    }

    private Curso getCursoVetor(String campo, String val)
    {
         boolean achei = false;
         int pos = 1;
         
         while ((achei == false) && (pos <= TotalRegsCurso))
         {
            if (campo.equals("Codigo"))
            {
                if (Integer.parseInt(val) == c[pos].getCodigo())
                {
                    achei = true;
                }
            }
            else
            {
                if (campo.equals("Nome"))
                {
                    if (val.equals(c[pos].getNome()))
                    {
                        achei = true;
                    }
                }
            }
            pos++;
         }

         if (achei == true)
         {
             return c[pos-1];
         }
         else
           return null;
    }


    private Curso getCurso(String campo, String val)
    {
         boolean achei = false;
         try
         {
               if (campo.equals("Codigo"))
                 BD.consultar("SELECT * FROM Cursos where Codigo = " + val);
               else
                 BD.consultar("SELECT * FROM Cursos where Nome = '" + val + "'");

               JOptionPane.showMessageDialog(null, "SELECT * FROM Cursos where Nome = '" + val + "'");
               if (BD.rs.next())
                {
               JOptionPane.showMessageDialog(null, "passei aqui");

                   achei = true;
                     curso.setCodigo(BD.rs.getInt(1));
                     curso.setNome(BD.rs.getString(2));
                }
                else
                    achei = false;

          }
          catch (Exception e)
          {
              e.printStackTrace();
          }


         if (achei == true)
         {
             return curso;
         }
         else
           return null;
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        butCadastrar = new javax.swing.JButton();
        butAlterar = new javax.swing.JButton();
        butExcluir = new javax.swing.JButton();
        butConfirmar = new javax.swing.JButton();
        butCancelar = new javax.swing.JButton();
        butFechar = new javax.swing.JButton();
        butPrimeiro = new javax.swing.JButton();
        butAnterior = new javax.swing.JButton();
        butProximo = new javax.swing.JButton();
        butUltimo = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        editCodigo = new javax.swing.JTextField();
        editNome = new javax.swing.JTextField();
        editTelefone = new javax.swing.JTextField();
        editEmail = new javax.swing.JTextField();
        jcbCurso = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        butCadastrar.setText("Cadastrar");
        butCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butCadastrarActionPerformed(evt);
            }
        });

        butAlterar.setText("Alterar");
        butAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butAlterarActionPerformed(evt);
            }
        });

        butExcluir.setText("Excluir");
        butExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butExcluirActionPerformed(evt);
            }
        });

        butConfirmar.setText("Confirmar");
        butConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butConfirmarActionPerformed(evt);
            }
        });

        butCancelar.setText("Cancelar");
        butCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butCancelarActionPerformed(evt);
            }
        });

        butFechar.setText("Fechar");
        butFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butFecharActionPerformed(evt);
            }
        });

        butPrimeiro.setText("<<");
        butPrimeiro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butPrimeiroActionPerformed(evt);
            }
        });

        butAnterior.setText("<");
        butAnterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butAnteriorActionPerformed(evt);
            }
        });

        butProximo.setText(">");
        butProximo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butProximoActionPerformed(evt);
            }
        });

        butUltimo.setText(">>");
        butUltimo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butUltimoActionPerformed(evt);
            }
        });

        jLabel1.setText("Código:");

        jLabel2.setText("Nome:");

        jLabel3.setText("Telefone:");

        jLabel4.setText("Email:");

        jLabel5.setText("Curso:");

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Código", "Nome", "Telefone", "Email", "Curso"
            }
        ));
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel5))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jcbCurso, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(butCadastrar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(butAlterar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(butExcluir)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(butConfirmar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(butCancelar)
                                .addGap(6, 6, 6)
                                .addComponent(butFechar))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(butPrimeiro)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(butAnterior, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(butProximo, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(editTelefone, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(editCodigo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 71, Short.MAX_VALUE))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel4)
                                            .addComponent(jLabel2))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(editEmail, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(editNome, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 171, Short.MAX_VALUE)))
                                    .addComponent(butUltimo, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 657, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(54, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(butCadastrar)
                    .addComponent(butAlterar)
                    .addComponent(butExcluir)
                    .addComponent(butConfirmar)
                    .addComponent(butCancelar)
                    .addComponent(butFechar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(butPrimeiro)
                    .addComponent(butAnterior)
                    .addComponent(butProximo)
                    .addComponent(butUltimo))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(editNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(editCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(editEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(editTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jcbCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
	       BD = new BancoDados();
           aluno = new Aluno();
           curso = new Curso();
	       State = "BROWSE";
	       StateChange();
	       AtualizaVetorCursos();
           AtualizaGrid();

           jcbCurso.addItem("");

//           for (int i = 1; i <= TotalRegsCurso; i++)
//               jcbCurso.addItem(c[i].getNome());

            try
            {
                BD.consultar("SELECT * FROM Cursos");
                while(BD.rs.next())
                {
                    jcbCurso.addItem(BD.rs.getString(2));
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
                      
           Localiza(1);
    }//GEN-LAST:event_formWindowOpened

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        // TODO add your handling code here:
   		BD.close();
		aluno = null;
                curso = null; 
    }//GEN-LAST:event_formWindowClosed

    private void butConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butConfirmarActionPerformed
        // TODO add your handling code here:
        if (State.equals("INSERT"))
        {
   		  aluno.setCodigo(Integer.parseInt(editCodigo.getText()));
		  aluno.setNome(editNome.getText());
          aluno.setTelefone(editTelefone.getText());
          aluno.setEmail(editEmail.getText());
          aluno.setCurso(getCurso("Nome", jcbCurso.getSelectedItem().toString()));
		  aluno.incluir(BD);
		  State = "BROWSE";
		  StateChange();
		  AtualizaGrid();
          Localiza(TotalRegsAluno);
        }
        else
        if (State.equals("EDIT"))
        {
      	  aluno.setCodigo(Integer.parseInt(editCodigo.getText()));
          aluno.setNome(editNome.getText());
          aluno.setTelefone(editTelefone.getText());
          aluno.setEmail(editEmail.getText());
          aluno.setCurso(getCurso("Nome", jcbCurso.getSelectedItem().toString()));
    	  aluno.alterar(BD);
    	  State = "BROWSE";
    	  editCodigo.setEditable(true);
    	  StateChange();
    	  AtualizaGrid();
        }
    }//GEN-LAST:event_butConfirmarActionPerformed

    private void butCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butCancelarActionPerformed
        // TODO add your handling code here:
       editCodigo.setText(Integer.toString(aluno.getCodigo()));
       editNome.setText(aluno.getNome());
       editTelefone.setText(aluno.getTelefone());
       editEmail.setText(aluno.getEmail());
       jcbCurso.setSelectedItem(aluno.getCurso().getNome());
       State = "BROWSE";
       editCodigo.setEditable(true);
       StateChange();
    }//GEN-LAST:event_butCancelarActionPerformed

    private void butFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butFecharActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_butFecharActionPerformed

    private void butCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butCadastrarActionPerformed
        // TODO add your handling code here:
        editCodigo.setText("");
		editNome.setText("");
        editTelefone.setText("");
        editEmail.setText("");
        jcbCurso.setSelectedIndex(0);
		State = "INSERT";
		StateChange();
    }//GEN-LAST:event_butCadastrarActionPerformed

    private void butAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butAlterarActionPerformed
        // TODO add your handling code here:
      editCodigo.setEditable(false);
  	  State = "EDIT";
	  StateChange();
    }//GEN-LAST:event_butAlterarActionPerformed

    private void butExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butExcluirActionPerformed
        // TODO add your handling code here:
       if (!(editCodigo.getText().equals("")))
       {
           aluno.setCodigo(Integer.parseInt(editCodigo.getText()));
    	   aluno.setNome(editNome.getText());
           aluno.setTelefone(editTelefone.getText());
           aluno.setEmail(editEmail.getText());
           aluno.setCurso(getCurso("Nome", jcbCurso.getSelectedItem().toString()));
    	   aluno.excluir(BD);
    	   State = "BROWSE";
    	   StateChange();
           AtualizaGrid();
           Localiza(TotalRegsAluno);
       }
    }//GEN-LAST:event_butExcluirActionPerformed

    private void butPrimeiroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butPrimeiroActionPerformed
        // TODO add your handling code here:
        Localiza(1);
    }//GEN-LAST:event_butPrimeiroActionPerformed

    private void butUltimoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butUltimoActionPerformed
        // TODO add your handling code here:
        Localiza(TotalRegsAluno);
    }//GEN-LAST:event_butUltimoActionPerformed

    private void butAnteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butAnteriorActionPerformed
        // TODO add your handling code here:
        Localiza(RegAtual-1);
    }//GEN-LAST:event_butAnteriorActionPerformed

    private void butProximoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butProximoActionPerformed
        // TODO add your handling code here:
        Localiza(RegAtual+1);
    }//GEN-LAST:event_butProximoActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        // TODO add your handling code here:
        Localiza(table.getSelectedRow()+1);
    }//GEN-LAST:event_tableMouseClicked

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFrameAluno().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton butAlterar;
    private javax.swing.JButton butAnterior;
    private javax.swing.JButton butCadastrar;
    private javax.swing.JButton butCancelar;
    private javax.swing.JButton butConfirmar;
    private javax.swing.JButton butExcluir;
    private javax.swing.JButton butFechar;
    private javax.swing.JButton butPrimeiro;
    private javax.swing.JButton butProximo;
    private javax.swing.JButton butUltimo;
    private javax.swing.JTextField editCodigo;
    private javax.swing.JTextField editEmail;
    private javax.swing.JTextField editNome;
    private javax.swing.JTextField editTelefone;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox jcbCurso;
    private javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables

}
