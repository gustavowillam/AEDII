/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javabdcurso;


/**
 *
 * @author Gustavo
 */
import javax.swing.JComboBox;

public class Curso 
{
	private int codigo;
        private String nome;        
	
        public Curso() 
	{
		codigo=0;
		nome="";
	}
	public int getCodigo() 
	{
		return codigo;
	}
	public void setCodigo(int Codigo) 
	{
		this.codigo = Codigo;
	}
	public String getNome() 
	{
		return nome;
	}
	public void setNome(String Nome) 
	{
		this.nome = Nome;
	}
	public void incluir(BancoDados BD)
	{
		String sql;
                sql = "INSERT INTO Cursos (Codigo, Nome) VALUES ("+codigo+",'"+nome+"');";		
                BD.atualizar(sql);
		try
		{
		 // BD.conn.commit();
		}
	    catch(Exception e) 
	    {
		    e.printStackTrace();
    	}		
	}
	public void alterar(BancoDados BD)
	{
		BD.atualizar("UPDATE Cursos SET nome='"+nome+"' WHERE Codigo = "+codigo);
	}
	public void excluir(BancoDados BD)
	{
		BD.atualizar("DELETE FROM Cursos WHERE Codigo = "+codigo);
	}       
        

        
  
        
        public JComboBox getjcbCurso(BancoDados BD)
        {
            JComboBox jcbCurso = new JComboBox();
            try
            {
                BD.consultar("SELECT * FROM cursos");
                while (BD.rs.next())
                {
                    jcbCurso.addItem(BD.rs.getInt(1)+"-"+BD.rs.getString(2));
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            return jcbCurso;
        }
}
