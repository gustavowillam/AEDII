/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javabdcurso;

/**
 *
 * @author Gustavo
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class BancoDados 
{
    Connection conn;
    Statement stmt;
    ResultSet rs;
//  String SGBD = "Firebird";
    String SGBD = "MySQL";
//  String SGBD = "Oracle";

    String servidor;
    String bancoDados;
    String usuario;
    String senha;

        
    public BancoDados()
    {

        if (SGBD.equals("Firebird") )
        {
            servidor = "localhost";
//            bancoDados = "jdbc:firebirdsql:localhost/3050:/home/gustavo/Documentos/DadosJava/Dados.fdb";
            bancoDados = "jdbc:firebirdsql:localhost/3050:E:/NetBeansProjects/Java-BD-NetBeans/src/javabdcurso/Dados.fdb";
            usuario = "SYSDBA"; 
            senha  = "masterkey";
        }

        if (SGBD.equals("MySQL") )
        {
            servidor = "localhost";
            bancoDados = "jdbc:mysql://localhost:3306/test"; 
            usuario = "root";
            senha = "19982004";             
        }

        if (SGBD.equals("Oracle") )
        {
            servidor = "127.0.0.1";
            bancoDados = "jdbc:oracle:thin:@127.0.0.1:1521:XE";           
            usuario = "SYSTEM";
            senha  = "19982004";
        }

        conectar(servidor, bancoDados, usuario, senha);
    }

    public boolean conectar(String servidor, String bancoDados, String usuario, String senha) 
    {
    	try 
    	{
           // Class.forName("sun.jdbc.odbc.JdbcOdbcDriver").newInstance();
   	   if (SGBD.equals("Firebird") )
             Class.forName("org.firebirdsql.jdbc.FBDriver");

           if (SGBD.equals("MySQL") )
             Class.forName("com.mysql.jdbc.Driver");

           if (SGBD.equals("Oracle") )
             Class.forName("oracle.jdbc.driver.OracleDriver");


        }
    	catch (Exception ex) 
    	{
            System.out.println("SQLException: " + ex.getMessage());
        }

        try
        {
            conn = DriverManager.getConnection(bancoDados, usuario, senha);
            stmt = conn.createStatement();

        } catch (SQLException ex) {
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
        return true;

    }
    public boolean atualizar (String comando) 
    {   
        try 
        {
            stmt.executeUpdate(comando); 
            return true;
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
            return false;
        }
    }
    
    public ResultSet consultar(String query) 
    {   
        try 
        {
            rs=stmt.executeQuery(query);
        } catch (Exception e) 
        {
            e.printStackTrace();
        }
        return rs;
    }
    
    public void close()  
    {
        try 
        {
            stmt.close();
        } 
        catch (SQLException sqlEx) 
        { 
            stmt = null;
        }
        try
        {
        	conn.close(); 
        } 
        catch (SQLException sqlEx) 
        { 
        	conn = null;
        }   
    }

}
