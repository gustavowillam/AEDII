/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javabdcurso;

/**
 *
 * @author Gustavo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
       JFramePrincipal FramePrincipal = new JFramePrincipal(); 
       FramePrincipal.setVisible(true); 
    }

}
