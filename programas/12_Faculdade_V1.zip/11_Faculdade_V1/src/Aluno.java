
public class Aluno 
{
    private String nomealuno, curso; 
    private Disciplina disc; 


    public Aluno()
    {
        
    }
    
    public Aluno(String na, String c, Disciplina d)
    {
        nomealuno = na; 
        curso = c; 
        disc =d; 

    }

    public String getNomealuno() {
        return nomealuno;
    }

    public void setNomealuno(String nomealuno) {
        this.nomealuno = nomealuno;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public Disciplina getDisc() {
        return disc;
    }

    public void setDisc(Disciplina disc) {
        this.disc = disc;
    }    
    
}
