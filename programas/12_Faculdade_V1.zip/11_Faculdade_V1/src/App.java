import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class App 
{
    public static void main(String[] args) 
    {
        Aluno a; 
        Disciplina d; 
        List<Aluno> alunos = new ArrayList<Aluno>(); 


        int opcao = 0, p;  
        String nd, na, cur;
        double nt;  

        while (opcao != 4)
        {
           opcao = Integer.parseInt(JOptionPane.showInputDialog(
            null, 
                  "1-Cadastrar Aluno\n" + 
                  "2-Pesquisar Aluno\n" + 
                  "3-Pesquisar Disciplina\n" + 
                  "4-Sair do programa")); 

           switch(opcao)
           {
              case 1: //cadastrar aluno  e disciplina 
                na = JOptionPane.showInputDialog(
                   null, "Digite o nome do aluno"); 
                cur = JOptionPane.showInputDialog(
                    null, "Digite o nome do curso"); 

                nd = JOptionPane.showInputDialog(
                        null, "Digite o nome da disciplina"); 
    
                nt =  Double.parseDouble(JOptionPane.showInputDialog(
                   null, "Digite a nota do aluno")); 

                d = new Disciplina(nd, nt); 
                
                a = new Aluno(na, cur, d);   //composição de objeto -> objeto disciplina dentro do objeto aluno 
                
                alunos.add(a); 
              break; 

              case 2:  //pesquisar aluno
                pesquisa_aluno(alunos);   //não tem retorno, porque pode ser encontrado uma lista de alunos e exibe todos os alunos que tem o nome pesquisado

              break; 
              
              case 3:  //pesquisar disciplina
                pesquisa_disciplina(alunos); 

              break; 
              
              case 4:  //sair do programa
              break; 

              default: 
                 JOptionPane.showMessageDialog(
                    null, "Opção Inválida.");  

           }  //fim do switch

        }  //fim do while 

    }  //fim do método main 
    
    public static void pesquisa_aluno(List<Aluno> alunos)
    {
        String na;   
        na = JOptionPane.showInputDialog(
            null, "Digite o nome do aluno"); 


        for (int i = 0; i < alunos.size(); i++)
        {
            if (na.equals(alunos.get(i).getNomealuno())) 
            {
                JOptionPane.showMessageDialog(
                    null, "Nome do Aluno :  " + alunos.get(i).getNomealuno() + "\n" + 
                                           "Curso do Aluno: " + alunos.get(i).getCurso() + "\n" + 
                                           "Discplina     : " + alunos.get(i).getDisc().getNomedisciplina() + "\n" +
                                           "Nota do Aluno : " + alunos.get(i).getDisc().getNota());  

            }
        }
    }

    public static void pesquisa_disciplina(List<Aluno> alunos)
    {
        String nd;   
        nd = JOptionPane.showInputDialog(
            null, "Digite o nome da disciplina"); 


        for (int i = 0; i < alunos.size(); i++)
        {
            if (nd.equals(alunos.get(i).getDisc().getNomedisciplina())) 
            {
                JOptionPane.showMessageDialog(
                    null, "Nome do Aluno :  " + alunos.get(i).getNomealuno() + "\n" + 
                                           "Curso do Aluno: " + alunos.get(i).getCurso() + "\n" + 
                                           "Discplina     : " + alunos.get(i).getDisc().getNomedisciplina() + "\n" +
                                           "Nota do Aluno : " + alunos.get(i).getDisc().getNota());  

            }
        }
    }

}  //fim da classe App
