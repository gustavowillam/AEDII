public class Disciplina
{
    private String nomedisciplina; 
    private double nota; 
    
    public Disciplina ()   //construtor vazio 
    {

    }
   
    public Disciplina(String nome, Double n)  //construtor sobrecarregado
    {
        nomedisciplina = nome; 
        nota  = n; 
    }

    public String getNomedisciplina() {
        return nomedisciplina;
    }

    public void setNomedisciplina(String nomedisciplina) {
        this.nomedisciplina = nomedisciplina;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }


}