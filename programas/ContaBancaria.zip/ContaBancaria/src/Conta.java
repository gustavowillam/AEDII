public class Conta {
    private String numero;
    private double saldo;
    private Cliente cliente; // cliente é um objeto do tipo Cliente

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String toString() {
        return "\n Número da conta: " + numero +
                "\n Saldo do conta:  " + saldo +
                // "Nome do cliente: " + cliente.getNome() +
                // "CPF do cliente : " + cliente.getCpf();
                cliente.toString();
    }

}
