import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {
        List<Conta> L = new ArrayList<Conta>();
        int opcao = 0;
        while (opcao != 5) {
            opcao = menu();
            if (opcao == 1) {
                Conta conta = new Conta();
                conta.setNumero(JOptionPane.showInputDialog(
                        "Digite o número da conta"));
                conta.setSaldo(0);

                Cliente cliente = new Cliente();
                cliente.setCpf(JOptionPane.showInputDialog(
                        "Digite o cpf do cliente"));
                cliente.setNome(JOptionPane.showInputDialog(
                        "Digite o nome do cliente"));

                conta.setCliente(cliente); // vincula o cliente na conta
                L.add(conta);
            }
            if (opcao == 2) { // deposito
                int p = pesquisa(L);
                if (p >= 0) {
                    double valor = (Double.parseDouble(
                            JOptionPane.showInputDialog(
                                    "Digite o valor para deposito.")));
                    L.get(p).setSaldo(L.get(p).getSaldo() + valor);
                } else
                    JOptionPane.showMessageDialog(null, "Conta não encontrada");
            }
            if (opcao == 3) { // saque
                int p = pesquisa(L);
                if (p >= 0) {
                    double valor = (Double.parseDouble(
                            JOptionPane.showInputDialog(
                                    "Digite o valor para saque.")));
                    L.get(p).setSaldo(L.get(p).getSaldo() - valor);
                } else
                    JOptionPane.showMessageDialog(null, "Conta não encontrada");
            }
            if (opcao == 4) { // exibir o saldo
                int p = pesquisa(L);
                if (p >= 0) {
                    JOptionPane.showMessageDialog(null, L.get(p).toString());
                } else
                    JOptionPane.showMessageDialog(null, "Conta não encontrada");
            }
        }
    }

    public static int menu() {
        int op;
        op = Integer.parseInt(JOptionPane.showInputDialog(
                "\n 1-Abrir conta" +
                        "\n 2-Deposito" +
                        "\n 3-Saque" +
                        "\n 4-Saldo" +
                        "\n 5-Sair do programa"));
        return op;
    }

    public static int pesquisa(List<Conta> L) {
        String n;
        n = JOptionPane.showInputDialog("Digite o número da conta: ");
        for (int i = 0; i < L.size(); i++) {
            if (n.equals(L.get(i).getNumero()))
                return i;
        }
        return -1;
    }
}
