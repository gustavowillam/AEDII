import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {

        List<Livro> L = new ArrayList<Livro>(); // cria a lista de livros

        int op = 0; // op -> opção do menu
        int p; // p -> posição onde o livro foi encontrado na lista

        while (op != 5) {
            op = menu(); // chama o método para exibir o menu
            switch (op) {
                case 1: // cadastrar Livro
                    Livro livro = new Livro(); // instancia um objeto do tipo livro
                    livro.setTitulo(JOptionPane.showInputDialog("Título"));
                    livro.setAutor(JOptionPane.showInputDialog("Autor"));
                    livro.setAno(Integer.parseInt(JOptionPane.showInputDialog("Ano")));
                    L.add(livro); // adiciona o objeto livro na lista L
                    break;
                case 2: // emprestimo
                    p = pesquisa(L); // retona a posição ou -1 se nao encontrar
                    if (p >= 0) // livro pesquisado está na lista
                        if (L.get(p).getEmprestado() == false) {
                            L.get(p).setEmprestado(true);
                            JOptionPane.showMessageDialog(null, "Empréstimo efetuado com sucesso");
                        } else
                            JOptionPane.showMessageDialog(null, "Livro Indisponível");
                    else // p = -1 -> livro não foi encontrado
                        JOptionPane.showMessageDialog(null, "Livro não encontrado");
                    break;
                case 3: // devolução
                    p = pesquisa(L); // retona a posição ou -1 se nao encontrar
                    if (p >= 0) // livro pesquisado está na lista
                        if (L.get(p).getEmprestado() == true) {
                            L.get(p).setEmprestado(false);
                            JOptionPane.showMessageDialog(null, "Devolução efetuado com sucesso");
                        } else
                            JOptionPane.showMessageDialog(null, "Livro disponível");
                    else
                        JOptionPane.showMessageDialog(null, "Livro não encontrado");
                    break;
                case 4: // Listagem
                    String acervo = "";
                    for (int i = 0; i < L.size(); i++) {
                        acervo = acervo + L.get(i).toString() + "\n";
                    }
                    JOptionPane.showMessageDialog(null, acervo);
                    break;
                case 5: // sair do programa
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção Inválida.");
            }
        }
    }

    public static int menu() {
        int op;
        op = Integer.parseInt(JOptionPane.showInputDialog(
                "1-Cadastrar Livro \n" +
                        "2- Emprestimo \n" +
                        "3- Devolucao \n" +
                        "4- Listagem de Livros disponíveis \n" +
                        "5- Sair do programa "));
        return op;
    }

    public static int pesquisa(List<Livro> L) {
        String t = JOptionPane.showInputDialog("Título");
        for (int i = 0; i < L.size(); i++) {
            if (t.equals(L.get(i).getTitulo()))
                return i; // retorna a posição onde o livro foi encontrado
        }
        return -1; // retorna -1 se não encontrar o livro na lista L
    }
}
