import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {
        List<Voo> LV = new ArrayList<Voo>();
        List<Passageiro> passagens = new ArrayList<Passageiro>();
        int opcao = -1;
        while (opcao != 0) {
            opcao = Integer.parseInt(
                    JOptionPane.showInputDialog(
                            "\n 1- Cadastrar Voo" +
                                    "\n 2- Venda de Passagens" +
                                    "\n 3- Listar Passageiros"));
            if (opcao == 1) { // cadastrar voo
                Voo v = new Voo();
                v.setNumero(JOptionPane.showInputDialog("Digite o número do voo"));
                v.setData(JOptionPane.showInputDialog("Digite o data do voo"));
                v.setOrigem(JOptionPane.showInputDialog("Digite a origem do voo"));
                v.setDestino(JOptionPane.showInputDialog("Digite o destino do voo"));
                LV.add(v);
            }
            if (opcao == 2) { // venda de passagens
                Passageiro p = new Passageiro();
                p.setCpf(JOptionPane.showInputDialog("Digite o CPF do Passageiro"));
                p.setNome(JOptionPane.showInputDialog("Digite o nome do passageiro"));
                int pos = pesquisa_voo(LV);
                if (pos >= 0) { // voo está cadastrado na sistema
                    p.setVoo(LV.get(pos));// vincula o voo ao passageiro
                    passagens.add(p); // adiciona o passageiro e o voo a lista de passagens
                } else
                    JOptionPane.showMessageDialog(null, "Voo não cadastrado");
            }
            if (opcao == 3) { // listagem de passagens vendidas por passageiro
                String cpf = JOptionPane.showInputDialog("Digite o CPF para pesquisar");
                String r = "";
                for (int i = 0; i < passagens.size(); i++) {
                    if (cpf.equals(passagens.get(i).getCpf())) {
                        r = r + "\n Passageiro : " + passagens.get(i).getNome() +
                                "\n Nr. Voo    : " + passagens.get(i).getVoo().getNumero() +
                                "\n Data Voo   : " + passagens.get(i).getVoo().getData() +
                                "\n Origem Voo : " + passagens.get(i).getVoo().getOrigem() +
                                "\n Destino Voo: " + passagens.get(i).getVoo().getDestino();
                    }
                }
                if (!r.equals(""))
                    JOptionPane.showMessageDialog(null, r);
                else
                    JOptionPane.showMessageDialog(null, "CPF não cadastrado!");
            }
        } // fim do while
    } // fim do main

    public static int pesquisa_voo(List<Voo> LV) { // retorna a posição do voo na lista LV
        String nr = JOptionPane.showInputDialog("Digite o número do voo");
        for (int i = 0; i < LV.size(); i++) {
            if (nr.equals(LV.get(i).getNumero()))
                return i; // voo encontrado na posição i
        }
        return -1; // voo não encontrado
    }
}
