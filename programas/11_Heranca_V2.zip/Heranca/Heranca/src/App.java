import java.util.ArrayList;
import java.util.List;

import Modelo.Conta;
import javax.swing.JOptionPane;

public class App 
{
    public static void main(String[] args) 
    {
        List<Conta> contas = new ArrayList<Conta>(); 

        int opcao = 0, p;  
        String ag, nc;
        double limite, perc, valor;  

        while (opcao != 7)
        {
           opcao = Integer.parseInt(JOptionPane.showInputDialog(
            null, 
                  "1-Abrir Conta Corrente\n" + 
                  "2-Abrir Conta Poupança\n" + 
                  "3-Deposito\n" + 
                  "4-Saque\n" + 
                  "5-Saldo\n" + 
                  "6-Atualizar Poupança\n" +                   
                  "7-Sair do programa")); 
           switch(opcao)
           {
              case 1:  //abrir conta corrente
              ag = JOptionPane.showInputDialog(
                   null, "Digite a agência"); 
              nc = JOptionPane.showInputDialog(
                   null, "Digite a conta"); 
              limite = Double.parseDouble(JOptionPane.showInputDialog(
                       null, "Digite o limite")); 

              Corrente cc = new Corrente(ag, nc, limite); 
              contas.add(cc); 

              break; 

              case 2:  //abrir conta poupança
              ag = JOptionPane.showInputDialog(
                   null, "Digite a agência"); 
              nc = JOptionPane.showInputDialog(
                   null, "Digite a conta"); 
              perc = Double.parseDouble(JOptionPane.showInputDialog(
                       null, "Digite o perc. rendimento")); 

              Poupanca cp = new Poupanca(ag, nc, perc); 
              contas.add(cp); 

              break; 

              case 3:  //deposito 
                p = pesquisa(contas); 
                if (p >= 0)
                {
                    valor = Double.parseDouble(JOptionPane.showInputDialog(
                        null, "Digite o valor")); 
                    contas.get(p).deposito(valor);
                }
                else 
                {
                   JOptionPane.showMessageDialog(
                    null, "Conta inválida.");   
                }

              break; 
              case 4: //saque 
               p = pesquisa(contas); 
                if (p >= 0)
                {
                    valor = Double.parseDouble(JOptionPane.showInputDialog(
                        null, "Digite o valor")); 
                    contas.get(p).saque(valor);
                }
                else 
                {
                    JOptionPane.showMessageDialog(
                    null, "Conta inválida.");   
                }

              
              break; 

              case 5:  //saldo
                p = pesquisa(contas); 
                if (p >= 0)
                {
                    String tipo; 
                    if (contas.get(p) instanceof Corrente )
                       tipo = "Conta Corrente";
                    else 
                       tipo = "Conta Poupança";     
                       
                    JOptionPane.showMessageDialog(
                        null,                             
                        "Tipo de Conta: " + tipo + "\n" +
                        "Saldo: " + contas.get(p).getSaldo());
                }
                else 
                {
                    JOptionPane.showMessageDialog(
                    null, "Conta inválida.");   
                }

              break; 
              
              case 6: //atualização poupança
              p = pesquisa(contas); 
              if (p >= 0)
              {
                if (contas.get(p) instanceof Poupanca )
                {
                    ((Poupanca) contas.get(p)).atualiza_poupanca();
                }
                else 
                   JOptionPane.showMessageDialog(
                    null, "Conta pesquisada não é Poupança.");    
              }
              else 
              {
                  JOptionPane.showMessageDialog(
                  null, "Conta inválida.");   
              }
              break; 

              case 7:  //sair do programa
              break; 

              default: 
                 JOptionPane.showMessageDialog(
                    null, "Opção Inválida.");  

           }  //fim do switch

        }  //fim do while 

    }  //fim do método main 
    
    public static int pesquisa(List<Conta> contas)
    {
        int pos = -1; 
        String nc;   
        nc = JOptionPane.showInputDialog(
            null, "Digite a conta"); 

        for (int i = 0; i < contas.size(); i++)
        {
            if (nc.equals(contas.get(i).getNumero())) 
               pos = i; 
        }
        return pos; 
    }


}  //fim da classe App
