import javax.swing.JOptionPane;

import Modelo.Conta;

public class Poupanca extends Conta
{
    double perc_rendimento;

    public void setPerc_rendimento(double perc_rendimento) {
        this.perc_rendimento = perc_rendimento;
    }

    public double getPerc_rendimento() {
        return perc_rendimento;
    }

    public Poupanca(String agencia, String numero, double perc_rendimento)
    {
        super(agencia, numero);
        this.perc_rendimento = perc_rendimento;
    } 

    public void saque (double valor)
    {
        if (valor <= getSaldo() )
           super.saque(valor);
        else 
           JOptionPane.showMessageDialog( 
                null, "Saldo insuficiente.");   
    }

    public void atualiza_poupanca()
    {
        saldo = getSaldo() + (perc_rendimento/100) * getSaldo();  
    }

}
