import javax.swing.JOptionPane;

public class Conta 
{
    private String agencia, numero; 
    private double saldo, limite; 
    private Cliente cliente; 

    public String get_agencia()
    {
        return agencia; 
    }
    public String get_numero()
    {
        return numero; 
    }
    public double get_saldo()
    {
        return saldo; 
    }
    public double get_limite()
    {
        return limite; 
    }
    public Cliente get_cliente()
    {
        return cliente;  
    }

    public void deposito(double valor)
    {
        saldo = saldo + valor; 
    }
    public void saque(double valor)
    {
        if (valor <= saldo + limite) 
          saldo = saldo - valor; 
        else
          JOptionPane.showMessageDialog(
            null, "Saldo Insuficiente.");  
    }

    public void cadastrar(String agencia, String numero, double limite, Cliente cliente)
    {
        this.agencia = agencia; 
        this.numero = numero;   
        this.limite = limite; 
        this.cliente = cliente; 
        saldo = 0;           
    }    
}
