import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class App 
{
    public static void main(String[] args) 
    {
        Conta c; 
        Cliente cli; 
        List<Conta> contas = new ArrayList<Conta>(); 
        List<Cliente> clientes = new ArrayList<Cliente>(); 

        int opcao = 0, p;  
        String ag, nc;
        String cpf, nome; 
        double limite, valor;  

        while (opcao != 5)
        {
           opcao = Integer.parseInt(JOptionPane.showInputDialog(
            null, 
                  "0-Cadastrar Cliente\n" + 
                  "1-Abrir Conta\n" + 
                  "2-Deposito\n" + 
                  "3-Saque\n" + 
                  "4-Saldo\n" + 
                  "5-Sair do programa")); 
           switch(opcao)
           {
              case 0: //cadastrar cliente  
                cpf = JOptionPane.showInputDialog(
                   null, "Digite o cpf"); 
                nome = JOptionPane.showInputDialog(
                   null, "Digite o nome"); 
                cli = new Cliente(); 
                cli.cadastrar(cpf, nome); 
                clientes.add(cli); 
              break; 

              case 1:  //abrir conta 
                p = pesquisa_cliente(clientes); 
                if (p >= 0)
                { 
                    ag = JOptionPane.showInputDialog(
                        null, "Digite a agência"); 
                    nc = JOptionPane.showInputDialog(
                            null, "Digite a conta"); 
                    limite = Double.parseDouble(JOptionPane.showInputDialog(
                                null, "Digite o limite")); 

                    c = new Conta(); 
                    c.cadastrar(ag, nc, limite, clientes.get(p) );
                    contas.add(c);           
                }
                else 
                {
                    JOptionPane.showMessageDialog(
                        null, "CPF Inválido.");
                }   

              break; 
              case 2:  //deposito 
                p = pesquisa(contas); 
                if (p >= 0)
                {
                    valor = Double.parseDouble(JOptionPane.showInputDialog(
                        null, "Digite o valor")); 
                    contas.get(p).deposito(valor);
                }
                else 
                {
                   JOptionPane.showMessageDialog(
                    null, "Conta inválida.");   
                }

              break; 
              case 3: //saque 
               p = pesquisa(contas); 
                if (p >= 0)
                {
                    valor = Double.parseDouble(JOptionPane.showInputDialog(
                        null, "Digite o valor")); 
                    contas.get(p).saque(valor);
                }
                else 
                {
                    JOptionPane.showMessageDialog(
                    null, "Conta inválida.");   
                }

              
              break; 

              case 4:  //saldo
                p = pesquisa(contas); 
                if (p >= 0)
                {
                    JOptionPane.showMessageDialog(
                        null, 
                           "Nome do Cliente: " + contas.get(p).get_cliente().get_nome() +  "\n" + 
                           "Saldo: " + contas.get(p).get_saldo());
                }
                else 
                {
                    JOptionPane.showMessageDialog(
                    null, "Conta inválida.");   
                }

              break; 
              
              case 5:  //sair do programa
              break; 

              default: 
                 JOptionPane.showMessageDialog(
                    null, "Opção Inválida.");  

           }  //fim do switch

        }  //fim do while 

    }  //fim do método main 
    
    public static int pesquisa(List<Conta> contas)
    {
        int pos = -1; 
        String nc;   
        nc = JOptionPane.showInputDialog(
            null, "Digite a conta"); 

        for (int i = 0; i < contas.size(); i++)
        {
            if (nc.equals(contas.get(i).get_numero())) 
               pos = i; 
        }
        return pos; 
    }

    public static int pesquisa_cliente(List<Cliente> clientes)
    {
        int pos = -1; 
        String cpf;   
        cpf = JOptionPane.showInputDialog(
            null, "Digite o cpf do cliente"); 
    
        for (int i = 0; i < clientes.size(); i++)
        {
            if (cpf.equals(clientes.get(i).get_cpf())) 
               pos = i; 
        }
        return pos; 
    }

}  //fim da classe App
