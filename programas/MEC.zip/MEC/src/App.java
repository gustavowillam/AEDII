import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {
        List<Curso> LC = new ArrayList<Curso>();
        List<Avaliacao> LA = new ArrayList<Avaliacao>();
        int p;
        int opcao = 0;
        while (opcao != 4) {
            opcao = Integer.parseInt(JOptionPane.showInputDialog(
                    "\n 1- Cadastrar Curso" +
                            "\n 2- Cadastrar Avaliação" +
                            "\n 3- Consultar Curso" +
                            "\n 4- Sair do Programa"));
            if (opcao == 1) { // Cadastrar Curso
                Curso c = new Curso();
                c.setNome(JOptionPane.showInputDialog("Digite o nome do curso"));
                c.setArea(JOptionPane.showInputDialog("Digite a área do curso"));
                c.setCarga_horaria(Integer.parseInt(
                        JOptionPane.showInputDialog("Digite a CH do curso")));
                LC.add(c);
            } // fim op == 1
            if (opcao == 2) { // Cadastrar Avaliação de Curso
                p = pesquisa_curso(LC);
                if (p >= 0) { // curso existe na instituição
                    double D1 = Double.parseDouble(
                            JOptionPane.showInputDialog(
                                    "Digite a nota da Dimensão 1"));
                    double D2 = Double.parseDouble(
                            JOptionPane.showInputDialog(
                                    "Digite a nota da Dimensão 2"));
                    double D3 = Double.parseDouble(
                            JOptionPane.showInputDialog(
                                    "Digite a nota da Dimensão 3"));
                    int ano = Integer.parseInt(
                            JOptionPane.showInputDialog(
                                    "Digite o ano de avaliação"));

                    Avaliacao a = new Avaliacao(ano, D1, D2, D3, LC.get(p));
                    LA.add(a);
                    JOptionPane.showMessageDialog(null, "Conceito do Curso: " + a.getConceito());

                    // LA.add(new Avaliacao(ano, D1, D2, D3, LC.get(p)));
                    // JOptionPane.showMessageDialog(null, "Conceito do Curso: " +
                    // LA.get(LA.size()-1).getConceito());
                } else
                    JOptionPane.showMessageDialog(null, "Curso Não Cadastrado.");
            } // fim op == 2
            if (opcao == 3) { // listagem de cursos avaliados
                p = pesquisa_curso(LC);
                if (p >= 0) {
                    String r = "Curso: " + LC.get(p).getNome();
                    for (int i = 0; i < LA.size(); i++) {
                        if (LC.get(p).getNome().equals(LA.get(i).getCurso().getNome())) {
                            r = r + "\n Ano: " + LA.get(i).getAno()
                                    + " Conceito: " + LA.get(i).getConceito();
                        }
                    }
                    JOptionPane.showMessageDialog(null, r);
                } else
                    JOptionPane.showMessageDialog(null, "Curso não Cadastrado");
            } // fim op = 3
        } // fim do while
    } // fim do main

    public static int pesquisa_curso(List<Curso> LC) {
        String nome = JOptionPane.showInputDialog("Digite o nome do curso");
        for (int i = 0; i < LC.size(); i++) {
            if (nome.equals(LC.get(i).getNome())) {
                return i; // curso encontrado na posição i
            }
        }
        return -1; // curso não encontrado
    }
}
