import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) {
        int opcao = Integer.parseInt(JOptionPane.showInputDialog(
                "\n 1- Cadastrar Curso" +
                        "\n 2- Cadastrar Avaliação" +
                        "\n 3- Consultar Curso"));

    }
}
