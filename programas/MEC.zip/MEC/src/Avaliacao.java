import javax.swing.JOptionPane;

public class Avaliacao {
    private int ano;
    private double Dim_1; // dimensão didática-pedagógica
    private double Dim_2; // dimensão corpo docente
    private double Dim_3; // dimensão infra-estrutura
    private int conceito; // conceito final do curso
    private Curso curso; // vincular a avaliação ao curso

    public Avaliacao(int ano, double D1, double D2, double D3, Curso curso) {
        setDim_1(D1);
        setDim_2(D2);
        setDim_3(D3);
        this.ano = ano;
        this.curso = curso;
        conceito = (int) ((D1 + D2 + D3) / 3);
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public double getDim_1() {
        return Dim_1;
    }

    public void setDim_1(double dim_1) {
        if ((dim_1 < 1) && (dim_1 > 5))
            JOptionPane.showMessageDialog(null, "Valor deve estar entre 1 e 5");
        else
            Dim_1 = dim_1;
    }

    public double getDim_2() {
        return Dim_2;
    }

    public void setDim_2(double dim_2) {
        if ((dim_2 < 1) && (dim_2 > 5))
            JOptionPane.showMessageDialog(null, "Valor deve estar entre 1 e 5");
        else
            Dim_2 = dim_2;
    }

    public double getDim_3() {
        return Dim_3;
    }

    public void setDim_3(double dim_3) {
        if ((dim_3 < 1) && (dim_3 > 5))
            JOptionPane.showMessageDialog(null, "Valor deve estar entre 1 e 5");
        else
            Dim_3 = dim_3;
    }

    public int getConceito() {
        return conceito;
    }

    public void setConceito() {
        conceito = (int) ((Dim_1 + Dim_2 + Dim_3) / 3);
    }

    public void calcula_conceito() {
        conceito = (int) ((Dim_1 + Dim_2 + Dim_3) / 3);
    }

}
