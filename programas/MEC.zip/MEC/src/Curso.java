import javax.swing.JOptionPane;

public class Curso {

    private String nome, area;
    private int carga_horaria;

    public int getCarga_horaria() {
        return carga_horaria;
    }

    public void setCarga_horaria(int carga_horaria) {
        if (carga_horaria > 0)
            this.carga_horaria = carga_horaria;
        else
            JOptionPane.showMessageDialog(null, "Carga horária deve ser maior que 0");
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}