public class Cliente
{
    private String cpf, nome; 
    
    public void cadastrar(String c, String n)
    {
        cpf = c; 
        nome = n; 
    }
    public String get_cpf()
    {
        return cpf; 
    }
    public String get_nome()
    {
        return nome; 
    }
    public void set_nome(String n)
    {
        nome = n; 
    }

}