import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) throws Exception {
        int N;
        String resposta = "";
        N = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o valor de N"));
        for (int i = 1; i <= 10; i++) {
            resposta = resposta + (N + " * " + i + " = " + N * i) + "\n";
            JOptionPane.showMessageDialog(null, resposta);
        }
    }
}
